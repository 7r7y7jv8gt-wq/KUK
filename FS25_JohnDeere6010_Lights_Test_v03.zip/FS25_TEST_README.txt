John Deere 6010 FS25 lights test v0.3
Both tractors are included. The requested edited lights are on the six-cylinder.
HOME/beacon toggle: 20 existing lightbar flash modules, two mirror flash modules
and two rear flash modules use FS25 inline beacon registrations with double flash.
The existing in-model emitting surfaces are used; donor lamps are not cloned on
top of the existing geometry. Each flash module has an amber light spill.
Normal lights: six white mirror diodes and five white front roof diodes emit from
the lens and inner surfaces. Seven rear roof diodes use red running-light cores
and separate brighter red brake lenses. All marker groups have gentle light spill
in both graphics light profiles. Lamp housings stay unlit.
The current FS25 node attribute and beaconLightConfigurations structure are used.
Original node order, transforms and binary geometry are preserved.
Install ZIP without extracting; disable older 6010 copies. Enable in a test save.
Buy the six-cylinder tractor; check normal lights, high beams, work lights, brakes,
turn signals, hazards and HOME beacons. Check the same in low/high graphics profiles.
Shader compilation, game loading, sound templates and native FS25 asset paths need
testing in your installed game. Send a fresh FS25 log.txt if anything fails.
This cloud machine has no FS25/Editor; these checks are static and mathematical.
The v0.2 legacy texture fallback and unused donor BKT variant limitations remain.
