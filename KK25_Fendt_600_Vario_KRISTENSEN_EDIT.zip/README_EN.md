# Fendt 600 Vario Gen1 – lighting package

Version 1.2.0.2 • FS25 PC • NorthernLight Modding

## Installation

1. Copy `FS25_Fendt600Vario_NLM.zip` into your active FS25 mods directory. Keep the ZIP intact.
2. Enable Fendt 600 Vario Gen1 when loading a save. Use this version instead of the original copy.
3. Buy it under medium tractors. Select Profi or Profi+ for the eight mirror markers.
4. Both MY24 and MY26 include the Optibeam and four grille flashers.

The vehicle is already connected. No manual XML editing or additional lighting script is required. The original optional integration support remains.

## Controls

- Position lights / first F setting: Optibeam cruise light, five roof position lights, seven existing step markers, four round white markers per Profi mirror, four red markers on each rear corner pillar, six ceiling LEDs and the existing mirror outline.
- High beam: all five existing roof driving lights, including forward-facing projected beams.
- Warning lights: Optibeam and four grille strobes. Lower left + upper right flash twice together, followed by two flashes from upper left + lower right. The sequence is AA–BB–AA–BB with no overlap between diagonals. Left and right are from the driver's seat.
- Optibeam retains Bygstad's original programming: side 1 `4 12 65 2`, side 2 `5 10 65 0`, intensity `1000`. The cruise light has separate position-light control.
- Position lights follow the light switch rather than engine start alone.

Existing lamp positions, rotations and scales are retained. Five reversed duplicate roof lamp assemblies are hidden; the existing forward-facing parts are used.

## Further editing

Vehicle XML: `data/vario600Gen1.xml`. Model: `data/vario600Gen1.i3d`. Connections use the existing vehicle `lights` and `i3dMappings`. Keep housing, optics and projected light together when modifying a mounting assembly.

Retain all six Optibeam entries in both `beaconLightConfigurations`. Mappings: `Blitz1`, `Blitz2`, `blitz1_reallight0`–`2`, `blitz2_reallight0`–`2`, `nlmOptibeamCruise`. Grille mappings: `nlmGrilleLeftUpper`, `nlmGrilleLeftLower`, `nlmGrilleRightUpper`, `nlmGrilleRightLower`.

Roof lamp mappings: `nlmRoofLamp1Position`–`5Position`, `nlmRoofLamp1MainGlow`–`5MainGlow`, `nlmRoofLamp1HighBeam`–`5HighBeam`. Marker mounts: `nlmMirrorLeft1`–`4`, `nlmMirrorRight1`–`4`, `nlmRearPillarLeft1`–`4`, `nlmRearPillarRight1`–`4`, `nlmCeiling1`–`6`.

If the hierarchy changes, select the actual node in GIANTS Editor, copy its Index Path and update its existing i3dMapping. Do not add a second `lights` section. These parts are fitted to this vehicle; paths and mounting positions are not universal prefab values.

## Validation status

Light controls were tested in FS25 1.23.1.0 with MY24 Profi, MY26 Profi and MY26 Power (1,048 checks). Diagonal double flashes were checked in the game. Files, mappings, exported mounting geometry and shader loading were checked. Multiplayer and a full driving/save-load test were not performed. The original model has a high polygon count; this is not a ModHub-approved release.

## Exact connection examples

These are excerpts from the already connected vehicle file, not additional sections to paste into it. Keep the grille entries in both existing beaconLightConfiguration choices. The mirror sharedLight belongs directly under lights, and node mappings belong in the existing i3dMappings.

```xml
<sharedLight xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" linkNode="nlmMirrorLeft1" filename="$data/shared/assets/lights/lizard/sideMarker07White.xml" lightTypes="0"/>
<beaconLight xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" node="nlmGrilleLeftLower" filename="lights/nlmFor9t/shared/aura_crossA.xml" variationName="BLINK"/>
<beaconLight xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" node="nlmGrilleRightUpper" filename="lights/nlmFor9t/shared/aura_crossA.xml" variationName="BLINK"/>
<beaconLight xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" node="nlmGrilleLeftUpper" filename="lights/nlmFor9t/shared/aura_crossB.xml" variationName="BLINK"/>
<beaconLight xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" node="nlmGrilleRightLower" filename="lights/nlmFor9t/shared/aura_crossB.xml" variationName="BLINK"/>
```

```xml
<i3dMapping xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="nlmGrilleLeftLower" node="0&gt;0|18"/>
<i3dMapping xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="nlmGrilleRightUpper" node="0&gt;0|19"/>
<i3dMapping xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="nlmGrilleLeftUpper" node="0&gt;0|17"/>
<i3dMapping xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="nlmGrilleRightLower" node="0&gt;0|20"/>
<i3dMapping xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="nlmMirrorLeft1" node="0&gt;0|2|5|1|4"/>
```

## Credits

NorthernLight Modding. Original tractor: Paul.; supplied edit: Kolbræk. Optibeam Dark Phantom: Bygstad. Additional original credits: BloodyRulez, LauserPlay, SirJoki80, B3N, Baba am Aparati, Retaurus, Flo724, Bobo, siLance. Installed round roof lamp models retain their BRIOD LIGHTS branding. Native referenced assets: GIANTS Software.
