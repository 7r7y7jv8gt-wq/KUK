# Fendt 600 Vario Gen1 – lyspakke

Versjon 1.2.0.2 • FS25 PC • NorthernLight Modding

## Installasjon

1. Legg `FS25_Fendt600Vario_NLM.zip` i den aktive modsmappen for FS25. Ikke pakk ut ZIP-filen.
2. Aktiver Fendt 600 Vario Gen1 når du laster lagringen. Bruk denne utgaven i stedet for originalkopien.
3. Traktoren ligger under mellomstore traktorer. Velg Profi eller Profi+ for de åtte speildiodene.
4. Både MY24 og MY26 har Optibeam og fire grillblitsere.

Alt er ferdig koblet i filene. Ingen manuell XML-redigering eller ekstra lysskript er nødvendig. Originaltraktorens støtte for valgfrie tillegg er beholdt.

## Betjening

- Parklys/første F-trinn: Optibeam cruise light, parklys i fem taklamper, sju eksisterende trinnlys, fire runde hvite dioder i hvert Profi-speil, fire røde dioder på hver bakre hjørnestolpe, seks dioder i innertaket og den eksisterende speilkonturen.
- Fjernlys: de fem eksisterende ekstralysene på taket, med lyskjegler fremover.
- Varsellys: Optibeam og fire grillblitsere. Nedre venstre + øvre høyre dobbeltblinker sammen, så dobbeltblinker øvre venstre + nedre høyre. Sekvensen er AA–BB–AA–BB uten at diagonalene lyser samtidig. Sidene regnes fra førerplassen.
- Optibeam beholder Bygstads originalprogram: side 1 `4 12 65 2`, side 2 `5 10 65 0`, intensitet `1000`. Cruise light styres separat med parklysene.
- Parklysene følger lysbryteren, ikke bare motorstart.

Eksisterende plasseringer, rotasjoner og skaleringer er beholdt. Fem feilvendte dobbeltsett av taklampene er skjult; de eksisterende fremovervendte delene brukes.

## Videre redigering

Kjøretøyfil: `data/vario600Gen1.xml`. Modell: `data/vario600Gen1.i3d`. Koblingene ligger i eksisterende `lights` og `i3dMappings`. Hold hus, optikk og lyskjegle sammen når et lampefeste redigeres.

Behold alle seks Optibeam-oppføringene i begge `beaconLightConfigurations`. Nodene er `Blitz1`, `Blitz2`, `blitz1_reallight0`–`2`, `blitz2_reallight0`–`2` og `nlmOptibeamCruise`. Grillen bruker `nlmGrilleLeftUpper`, `nlmGrilleLeftLower`, `nlmGrilleRightUpper` og `nlmGrilleRightLower`.

Taklampene bruker `nlmRoofLamp1Position`–`5Position`, `nlmRoofLamp1MainGlow`–`5MainGlow` og `nlmRoofLamp1HighBeam`–`5HighBeam`. Øvrige fester: `nlmMirrorLeft1`–`4`, `nlmMirrorRight1`–`4`, `nlmRearPillarLeft1`–`4`, `nlmRearPillarRight1`–`4` og `nlmCeiling1`–`6`.

Etter endret hierarki: velg den faktiske noden i GIANTS Editor, kopier Index Path og oppdater den eksisterende i3dMapping-oppføringen. Ikke opprett en ekstra `lights`-seksjon. Delene er tilpasset dette kjøretøyet; indeksene og festeplasseringene gjelder ikke automatisk andre kjøretøy.

## Kontrollstatus

Lysbryterne er testet i FS25 1.23.1.0 med MY24 Profi, MY26 Profi og MY26 Power (1 048 kontroller). Diagonal dobbeltblink er kontrollert i spillet. Filer, koblinger, eksportert festegeometri og shaderlasting er kontrollert. Multiplayer og en full kjøre-/lagringstest er ikke utført. Originalmodellen har mange polygoner og er ikke ModHub-godkjent.

## Nøyaktige koblingseksempler

Dette er utdrag fra den ferdigkoblede kjøretøyfilen, ikke ekstra seksjoner som skal limes inn. Behold grilloppføringene i begge eksisterende beaconLightConfiguration-valg. Speillysets sharedLight ligger direkte under lights, og nodene i eksisterende i3dMappings.

```xml
<sharedLight xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" linkNode="nlmMirrorLeft1" filename="$data/shared/assets/lights/lizard/sideMarker07White.xml" lightTypes="0"/>
<beaconLight xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" node="nlmGrilleLeftLower" filename="lights/nlmFor9t/shared/aura_crossA.xml" variationName="BLINK"/>
<beaconLight xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" node="nlmGrilleRightUpper" filename="lights/nlmFor9t/shared/aura_crossA.xml" variationName="BLINK"/>
<beaconLight xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" node="nlmGrilleLeftUpper" filename="lights/nlmFor9t/shared/aura_crossB.xml" variationName="BLINK"/>
<beaconLight xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" node="nlmGrilleRightLower" filename="lights/nlmFor9t/shared/aura_crossB.xml" variationName="BLINK"/>
```

```xml
<i3dMapping xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="nlmGrilleLeftLower" node="0&gt;0|18"/>
<i3dMapping xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="nlmGrilleRightUpper" node="0&gt;0|19"/>
<i3dMapping xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="nlmGrilleLeftUpper" node="0&gt;0|17"/>
<i3dMapping xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="nlmGrilleRightLower" node="0&gt;0|20"/>
<i3dMapping xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="nlmMirrorLeft1" node="0&gt;0|2|5|1|4"/>
```

## Credits

NorthernLight Modding. Original tractor: Paul.; supplied edit: Kolbræk. Optibeam Dark Phantom: Bygstad. Additional original credits: BloodyRulez, LauserPlay, SirJoki80, B3N, Baba am Aparati, Retaurus, Flo724, Bobo, siLance. Installed round roof lamp models retain their BRIOD LIGHTS branding. Native referenced assets: GIANTS Software.
