# Fendt 600 Vario Gen1 – ljuspaket

Version 1.2.0.2 • FS25 PC • NorthernLight Modding

## Installation

1. Lägg `FS25_Fendt600Vario_NLM.zip` i den FS25-modsmapp som du använder. Packa inte upp ZIP-filen.
2. Aktivera Fendt 600 Vario Gen1 när du startar sparningen. Använd denna version i stället för originalkopian.
3. Köp traktorn i kategorin medelstora traktorer. Välj Profi eller Profi+ för de åtta spegeldioderna.
4. Båda valen MY24 och MY26 innehåller Optibeam och de fyra grillblixtarna.

Allt är redan inkopplat. Inga manuella XML-ändringar eller extra ljusskript krävs. Originaltraktorns förberedelser för valfria tillägg finns kvar.

## Ljusreglage

- Positionsljus/första F-läget: Optibeams cruise light, fem taklampors positionsljus, sju befintliga instegslampor, fyra runda vita dioder i varje Profi-spegel, fyra röda dioder på vardera bakre hörnstolpe, sex dioder i innertaket och den befintliga spegelkonturen.
- Helljus: de fem befintliga extraljusen på taket, med riktiga framåtriktade ljuskäglor.
- Varningsljus: Optibeam och de fyra grillblixtarna. Nedre vänster + övre höger dubbelblinkar tillsammans; därefter dubbelblinkar övre vänster + nedre höger. Sekvensen är AA–BB–AA–BB, utan att de två diagonalerna lyser samtidigt. Vänster/höger räknas från förarplatsen.
- Optibeam använder Bygstads original: sida 1 `4 12 65 2`, sida 2 `5 10 65 0`, intensitet `1000`. Cruise light är separat från blixten.
- Positionsljusen styrs av ljusreglaget, inte enbart av motorstart.

De befintliga lampornas positioner, rotationer och skalning är bevarade. De fem felvända dubbletterna av taklamporna är dolda; de redan monterade rättvända delarna används.

## Om du redigerar modellen vidare

Fordonsfil: `data/vario600Gen1.xml`. Modell: `data/vario600Gen1.i3d`. Kopplingarna finns i fordonets befintliga `lights` och `i3dMappings`. Flytta inte bara en ljusyta: hus, optik och ljuskägla måste följa samma fäste.

Behåll alla sex Optibeam-poster i båda `beaconLightConfigurations`. Noderna heter `Blitz1`, `Blitz2`, `blitz1_reallight0`–`2`, `blitz2_reallight0`–`2` och `nlmOptibeamCruise`. Grillen använder `nlmGrilleLeftUpper`, `nlmGrilleLeftLower`, `nlmGrilleRightUpper` och `nlmGrilleRightLower`.

Taklampornas kopplingar heter `nlmRoofLamp1Position`–`5Position`, `nlmRoofLamp1MainGlow`–`5MainGlow` och `nlmRoofLamp1HighBeam`–`5HighBeam`. Övriga fästen: `nlmMirrorLeft1`–`4`, `nlmMirrorRight1`–`4`, `nlmRearPillarLeft1`–`4`, `nlmRearPillarRight1`–`4` och `nlmCeiling1`–`6`.

Vid ändrad hierarki: välj den faktiska noden i GIANTS Editor, kopiera dess Index Path och uppdatera motsvarande befintliga i3dMapping. Skapa inte en andra `lights`-sektion. Delarna är fordonsanpassade; index och fästpositioner gäller inte automatiskt ett annat fordon.

## Kontrollstatus

Ljusreglagen är provade i FS25 1.23.1.0 med MY24 Profi, MY26 Profi och MY26 Power (1 048 kontroller). Diagonalt dubbelblink har kontrollerats i spelet. Filer, kopplingar, exporterad monteringsgeometri och shaderladdning är kontrollerade. Multiplayer och fullständig körning/sparning har inte provats. Originalmodellen har hög polygonmängd; den är inte ModHub-godkänd.

## Exakta kopplingsexempel

Detta är utdrag ur den redan färdigkopplade fordonsfilen, inte ytterligare sektioner att klistra in. Behåll grillposterna i båda befintliga beaconLightConfiguration-valen. Spegelljuset ligger direkt i lights, och nodkopplingarna i befintliga i3dMappings.

```xml
<sharedLight xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" linkNode="nlmMirrorLeft1" filename="$data/shared/assets/lights/lizard/sideMarker07White.xml" lightTypes="0"/>
<beaconLight xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" node="nlmGrilleLeftLower" filename="lights/nlmFor9t/shared/aura_crossA.xml" variationName="BLINK"/>
<beaconLight xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" node="nlmGrilleRightUpper" filename="lights/nlmFor9t/shared/aura_crossA.xml" variationName="BLINK"/>
<beaconLight xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" node="nlmGrilleLeftUpper" filename="lights/nlmFor9t/shared/aura_crossB.xml" variationName="BLINK"/>
<beaconLight xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" node="nlmGrilleRightLower" filename="lights/nlmFor9t/shared/aura_crossB.xml" variationName="BLINK"/>
```

```xml
<i3dMapping xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="nlmGrilleLeftLower" node="0&gt;0|18"/>
<i3dMapping xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="nlmGrilleRightUpper" node="0&gt;0|19"/>
<i3dMapping xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="nlmGrilleLeftUpper" node="0&gt;0|17"/>
<i3dMapping xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="nlmGrilleRightLower" node="0&gt;0|20"/>
<i3dMapping xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="nlmMirrorLeft1" node="0&gt;0|2|5|1|4"/>
```

## Credits

NorthernLight Modding. Original tractor: Paul.; supplied edit: Kolbræk. Optibeam Dark Phantom: Bygstad. Additional original credits: BloodyRulez, LauserPlay, SirJoki80, B3N, Baba am Aparati, Retaurus, Flo724, Bobo, siLance. Installed round roof lamp models retain their BRIOD LIGHTS branding. Native referenced assets: GIANTS Software.
