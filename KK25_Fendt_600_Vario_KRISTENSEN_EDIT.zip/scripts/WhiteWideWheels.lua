-- Scope all adaptations to the two white-letter wheel choices in this mod.
local modDirectory = g_currentModDirectory
local vehicleFilename = modDirectory .. "data/vario600Gen1.xml"
local whiteBktTexture = modDirectory .. "BKTHVIT/Skrifta/12412.png"

-- Let the original wide-wheel generator choose its original BKT meshes,
-- physics, rims and radius-dependent axle offsets. Keep only its BKT result.
local nativeGenerate = VehicleConfigurationItemWheel.generateConfigurations
VehicleConfigurationItemWheel.generateConfigurations = function(items, xmlFile, configName, baseConfigItem)
    if xmlFile.filename ~= vehicleFilename or baseConfigItem.saveId ~= "BKT_WHITE" then
        return nativeGenerate(items, xmlFile, configName, baseConfigItem)
    end

    local previousCount = #items
    nativeGenerate(items, xmlFile, configName, baseConfigItem)
    for index = #items, previousCount + 1, -1 do
        local combination = items[index].tireCombination
        local brand = combination ~= nil and combination.wheelBrand or nil
        if brand == nil or string.upper(brand.name or "") ~= "BKT" then
            table.remove(items, index)
        end
    end
    for index = previousCount + 1, #items do
        items[index]:setIndex(index)
        items[index].configKey = string.format("vehicle.wheels.wheelConfigurations.wheelConfiguration(%d)", index - 1)
    end
end

-- Keep the Nokian option at the same vehicle stance as the factory broad
-- option, compensating for the uploaded Nokian tyres' different radii.
local nativeLoad = VehicleConfigurationItemWheel.loadFromXML
VehicleConfigurationItemWheel.loadFromXML = function(self, xmlFile, baseKey, configKey, baseDirectory, customEnvironment)
    if xmlFile.filename == vehicleFilename and xmlFile:getValue(configKey .. "#saveId") == "NOKIAN_WHITE" then
        local radii = {0.6748, 0.6748, 0.9936, 0.9936}
        local broadOffsets = {-0.055, -0.055, -0.035, -0.035}
        for index = 1, 4 do
            local originalKey = string.format("vehicle.wheels.wheelConfigurations.wheelConfiguration(0).wheels.wheel(%d)", index - 1)
            local dimension = xmlFile:getValue(originalKey .. "#dimensions")
            local baseRadius = dimension ~= nil and g_wheelManager:getWheelRadiusAndWidthFromDimension(dimension) or nil
            if baseRadius ~= nil then
                local targetKey = string.format("%s.wheels.wheel(%d).physics#yOffset", configKey, index - 1)
                xmlFile:setValue(targetKey, broadOffsets[index] - (baseRadius - radii[index]))
            end
        end
    end
    return nativeLoad(self, xmlFile, baseKey, configKey, baseDirectory, customEnvironment)
end

-- The native material override recurses into the mud mesh too. Apply this
-- one white BKT texture only to vehicleShader tyre materials, preserving mud.
local nativeApply = VehicleMaterial.apply
VehicleMaterial.apply = function(self, node, targetMaterialSlotName, colorOnly)
    if self.diffuseMap ~= whiteBktTexture then
        return nativeApply(self, node, targetMaterialSlotName, colorOnly)
    end

    local targetSlot = targetMaterialSlotName or self.targetMaterialSlotName
    local success = false
    local function visit(current)
        if getHasClassId(current, ClassIds.SHAPE) then
            for index = 0, getNumOfMaterials(current) - 1 do
                local slot = getMaterialSlotName(current, index)
                if targetSlot == nil or slot == targetSlot then
                    local materialId = getMaterial(current, index)
                    local shader = string.lower(getMaterialCustomShaderFilename(materialId) or "")
                    if shader:sub(-17) == "vehicleshader.xml" then
                        self:applyToMaterial(current, index, colorOnly)
                        success = true
                    end
                end
            end
        end
        for index = 0, getNumOfChildren(current) - 1 do
            visit(getChildAt(current, index))
        end
    end
    visit(node)
    return success
end
