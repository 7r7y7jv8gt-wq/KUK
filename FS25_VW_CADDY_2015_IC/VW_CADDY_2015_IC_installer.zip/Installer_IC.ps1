﻿[CmdletBinding()]
param([string]$ModFolder)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$backupDir = $null
$didBeginOverwrite = $false
$stagedFiles = New-Object System.Collections.Generic.List[string]

try {
    $root = $PSScriptRoot
    $manifest = Get-Content -LiteralPath (Join-Path $root 'patch_manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.formatVersion -ne 1) { throw 'Ukjent patchversjon.' }
    Add-Type -TypeDefinition ([IO.File]::ReadAllText((Join-Path $root 'CaddyICPatch.cs'))) -Language CSharp

    foreach ($entry in $manifest.payloadFiles) {
        $path = Join-Path (Join-Path $root 'filer') $entry.name
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw ('Mangler patchfil: ' + $entry.name) }
        if ([CaddyICPatch]::FileSHA256($path) -ne $entry.sha256) { throw ('Skadet patchfil: ' + $entry.name) }
    }
    $indices = New-Object System.Collections.Generic.List[int]
    $types = New-Object System.Collections.Generic.List[int]
    $deltaFiles = New-Object System.Collections.Generic.List[string]
    foreach ($entry in $manifest.changes) {
        if ([IO.Path]::GetFileName([string]$entry.file) -ne [string]$entry.file) { throw 'Ugyldig patchnavn.' }
        $path = Join-Path (Join-Path $root 'modelldata') $entry.file
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw ('Mangler patchdata: ' + $entry.file) }
        if ([CaddyICPatch]::FileSHA256($path) -ne $entry.gzipSHA256) { throw 'Skadede modelldata i patchen.' }
        $indices.Add([int]$entry.index)
        $types.Add([int]$entry.type)
        $deltaFiles.Add($path)
    }

    if ([string]::IsNullOrWhiteSpace($ModFolder)) {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = 'Velg den utpakkede FS25_VW_CADDY_2015-mappen (mappen med modDesc.xml).'
        $dialog.ShowNewFolderButton = $false
        $defaultFolder = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'My Games\FarmingSimulator2025\mods'
        if (Test-Path -LiteralPath $defaultFolder -PathType Container) { $dialog.SelectedPath = $defaultFolder }
        try {
            if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
                Write-Host 'Avbrutt. Ingen filer er endret.'
                exit 0
            }
            $ModFolder = $dialog.SelectedPath
        } finally { $dialog.Dispose() }
    }
    $ModFolder = (Resolve-Path -LiteralPath $ModFolder).Path
    $names = @($manifest.shapesFilename) + @($manifest.payloadFiles | ForEach-Object { $_.name })
    foreach ($name in $names) {
        if (-not (Test-Path -LiteralPath (Join-Path $ModFolder $name) -PathType Leaf)) {
            throw ('Velg selve den utpakkede Caddy-mappen. Finner ikke ' + $name)
        }
    }
    $sourceShapes = Join-Path $ModFolder $manifest.shapesFilename
    $currentShapesHash = [CaddyICPatch]::FileSHA256($sourceShapes)
    $alreadyInstalled = $currentShapesHash -eq $manifest.targetSHA256
    if ($alreadyInstalled) {
        foreach ($entry in $manifest.payloadFiles) {
            if ([CaddyICPatch]::FileSHA256((Join-Path $ModFolder $entry.name)) -ne $entry.sha256) {
                $alreadyInstalled = $false
            }
        }
        if ($alreadyInstalled) {
            Write-Host 'Interactive Control-patchen er allerede installert.' -ForegroundColor Green
            exit 0
        }
    }

    Write-Host 'Lager modell med bevegelige dorer og bakluke. Dette kan ta litt tid ...'
    $tempShapes = Join-Path $ModFolder ('.caddy_ic_' + [Guid]::NewGuid().ToString('N') + '.tmp')
    $stagedFiles.Add($tempShapes)
    [CaddyICPatch]::Build($sourceShapes, $tempShapes, [int]$manifest.originalEntityCount,
        [int]$manifest.targetEntityCount, $indices.ToArray(), $types.ToArray(), $deltaFiles.ToArray(),
        [string]$manifest.originalSHA256, [string]$manifest.targetSHA256)

    # Stage every small replacement before backing up or changing any originals.
    $stagedPayload = @{}
    foreach ($entry in $manifest.payloadFiles) {
        $tmp = Join-Path $ModFolder ('.caddy_ic_' + [Guid]::NewGuid().ToString('N') + '.tmp')
        $stagedFiles.Add($tmp)
        [IO.File]::Copy((Join-Path (Join-Path $root 'filer') $entry.name), $tmp, $false)
        if ([CaddyICPatch]::FileSHA256($tmp) -ne $entry.sha256) { throw 'Kopieringen av patchfilene feilet.' }
        $stagedPayload[$entry.name] = $tmp
    }

    $backupDir = Join-Path $ModFolder ('IC_sikkerhetskopi_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + [Guid]::NewGuid().ToString('N').Substring(0, 6))
    [IO.Directory]::CreateDirectory($backupDir) | Out-Null
    foreach ($name in $names) {
        $original = Join-Path $ModFolder $name
        $backup = Join-Path $backupDir $name
        [IO.File]::Copy($original, $backup, $false)
        if ([CaddyICPatch]::FileSHA256($original) -ne [CaddyICPatch]::FileSHA256($backup)) {
            throw ('Sikkerhetskopieringen feilet for ' + $name)
        }
    }

    $didBeginOverwrite = $true
    [IO.File]::Replace($tempShapes, $sourceShapes, $null)
    foreach ($entry in $manifest.payloadFiles) {
        [IO.File]::Replace($stagedPayload[$entry.name], (Join-Path $ModFolder $entry.name), $null)
    }
    Write-Host ''
    Write-Host 'Ferdig! Interactive Control er lagt til pa dorene og bakluka.' -ForegroundColor Green
    Write-Host 'Aktiver ogsa FS25_interactiveControl i lagringen.'
    Write-Host ('Sikkerhetskopi: ' + $backupDir)
} catch {
    $message = $_.Exception.Message
    if ($didBeginOverwrite -and $backupDir) {
        $rollbackOk = $true
        foreach ($name in $names) {
            try { [IO.File]::Copy((Join-Path $backupDir $name), (Join-Path $ModFolder $name), $true) }
            catch { $rollbackOk = $false }
        }
        if ($rollbackOk) { Write-Host 'Originalfilene er gjenopprettet fra sikkerhetskopien.' }
        else { Write-Host ('Gjenopprett de fire filene fra sikkerhetskopien: ' + $backupDir) -ForegroundColor Yellow }
    } else {
        Write-Host 'Originalfilene er urort.'
    }
    Write-Host ('Kunne ikke installere: ' + $message) -ForegroundColor Red
    exit 1
} finally {
    foreach ($path in $stagedFiles) {
        if (Test-Path -LiteralPath $path -PathType Leaf) {
            Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
        }
    }
}
