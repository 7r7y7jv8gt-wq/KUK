// Caddy IC entity patcher; .NET Framework / Windows PowerShell 5.1 compatible.
// Cipher logic adapted from I3DShapesTool, Copyright (c) 2017 Daniel Hultgren.
// MIT license and source attribution are included in THIRD_PARTY_NOTICES.txt.
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;

public static class CaddyICPatch
{
    // Only the original Caddy's v10 seed 26 is supported by this patch.
    private static readonly uint[] SeedKey = new uint[] { 0xE2E3E5E5U, 0xE5E5E5E3U, 0xE5E4E5E4U, 0xE3E5E3E1U, 0xE2E2E3E3U, 0xE3E1E0E1U, 0xE2E2E3E5U, 0xDEE1DFE1U, 0xE1E1E0DEU, 0x2579C0DAU, 0x2B291F1AU, 0x2F2E2B2AU, 0x4D453C31U, 0x4D4E5458U, 0x3B424647U, 0x413A3F3BU };

    public static string FileSHA256(string path)
    {
        using (SHA256 sha = SHA256.Create())
        using (FileStream f = File.OpenRead(path))
            return BitConverter.ToString(sha.ComputeHash(f)).Replace("-", "").ToLowerInvariant();
    }

    private sealed class Cipher
    {
        private ulong counter;
        private readonly uint[] key = (uint[])SeedKey.Clone();
        private readonly uint[] t = new uint[16];
        private static uint Rol(uint x, int n) { return (x << n) | (x >> (32 - n)); }
        private static uint Ror(uint x, int n) { return (x >> n) | (x << (32 - n)); }
        private static void S1(uint[] k, int a, int b, int c, int d)
        {
            unchecked {
                k[c] ^= Rol(k[b] + k[a], 7);
                k[d] ^= Rol(k[c] + k[a], 9);
                k[b] ^= Rol(k[c] + k[d], 13);
                k[a] ^= Ror(k[b] + k[d], 14);
            }
        }
        private static void S2(uint[] k, int a, int b, int c, int d)
        {
            unchecked {
                k[c] ^= Rol(k[b] + k[a], 7);
                k[d] ^= Rol(k[b] + k[c], 9);
                k[a] ^= Rol(k[c] + k[d], 13);
                k[b] ^= Ror(k[d] + k[a], 14);
            }
        }
        public void Transform(byte[] data)
        {
            unchecked {
                for (int off = 0; off < data.Length; off += 64)
                {
                    key[8] = (uint)counter;
                    key[9] = (uint)(counter >> 32);
                    Array.Copy(key, t, 16);
                    for (int round = 0; round < 10; round++)
                    {
                        S1(t, 0, 12, 4, 8); S1(t, 5, 1, 9, 13);
                        S1(t, 10, 6, 14, 2); S1(t, 15, 11, 3, 7);
                        S2(t, 3, 0, 1, 2); S2(t, 4, 5, 6, 7);
                        S1(t, 10, 9, 11, 8); S2(t, 14, 15, 12, 13);
                    }
                    int end = Math.Min(64, data.Length - off);
                    for (int word = 0; word * 4 < end; word++)
                    {
                        uint mask = key[word] + t[word];
                        int count = Math.Min(4, end - word * 4);
                        for (int b = 0; b < count; b++)
                            data[off + word * 4 + b] ^= (byte)(mask >> (b * 8));
                    }
                    counter++;
                }
            }
        }
    }

    private static byte[] ReadExact(Stream stream, int count)
    {
        if (count < 0 || count > 536870912)
            throw new InvalidDataException("Ugyldig storrelse i modellfilen.");
        byte[] data = new byte[count];
        int pos = 0;
        while (pos < count)
        {
            int n = stream.Read(data, pos, count - pos);
            if (n == 0) throw new EndOfStreamException("Modellfilen er ufullstendig.");
            pos += n;
        }
        return data;
    }
    private static byte[] ReadChunk(Stream stream, Cipher cipher, int count)
    {
        byte[] data = ReadExact(stream, count);
        cipher.Transform(data);
        return data;
    }
    private static int ReadInt(Stream stream, Cipher cipher)
    {
        return BitConverter.ToInt32(ReadChunk(stream, cipher, 4), 0);
    }
    private static void WriteChunk(Stream stream, Cipher cipher, byte[] plain)
    {
        // Keep caller-owned payloads intact, so hash and byte checks are possible.
        byte[] data = (byte[])plain.Clone();
        cipher.Transform(data);
        stream.Write(data, 0, data.Length);
    }
    private static void WriteInt(Stream stream, Cipher cipher, int value)
    {
        WriteChunk(stream, cipher, BitConverter.GetBytes(value));
    }
    private static byte[] Unzip(string path)
    {
        using (FileStream f = File.OpenRead(path))
        using (GZipStream zip = new GZipStream(f, CompressionMode.Decompress))
        using (MemoryStream output = new MemoryStream())
        {
            zip.CopyTo(output);
            if (output.Length > 536870912) throw new InvalidDataException("Patchdata er for store.");
            return output.ToArray();
        }
    }

    public static void Build(string source, string destination, int originalCount,
                             int targetCount, int[] indices, int[] types, string[] files,
                             string originalSHA256, string targetSHA256)
    {
        if (!String.Equals(FileSHA256(source), originalSHA256, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Feil Caddy-versjon. Velg den originale modmappen du sendte.");
        if (originalCount < 1 || targetCount < originalCount || targetCount > 1000000 ||
            indices.Length != types.Length || indices.Length != files.Length)
            throw new InvalidDataException("Ugyldig patchbeskrivelse.");
        Dictionary<int, int> change = new Dictionary<int, int>();
        for (int i = 0; i < indices.Length; i++)
        {
            if (indices[i] < 0 || indices[i] >= targetCount || change.ContainsKey(indices[i]))
                throw new InvalidDataException("Ugyldig delnummer i patchen.");
            change.Add(indices[i], i);
        }
        for (int i = originalCount; i < targetCount; i++)
            if (!change.ContainsKey(i)) throw new InvalidDataException("Patchdata mangler.");
        using (FileStream input = File.OpenRead(source))
        using (FileStream output = new FileStream(destination, FileMode.CreateNew, FileAccess.Write, FileShare.None))
        {
            byte[] header = ReadExact(input, 4);
            if (header[0] != 10 || header[1] != 0 || header[2] != 26 || header[3] != 0)
                throw new InvalidDataException("Modellformatet passer ikke denne patchen.");
            output.Write(header, 0, 4);
            Cipher read = new Cipher();
            Cipher write = new Cipher();
            if (ReadInt(input, read) != originalCount)
                throw new InvalidDataException("Antall modelldeler stemmer ikke.");
            WriteInt(output, write, targetCount);
            for (int index = 0; index < targetCount; index++)
            {
                int type = 0;
                byte[] body = null;
                if (index < originalCount)
                {
                    type = ReadInt(input, read);
                    int size = ReadInt(input, read);
                    body = ReadChunk(input, read, size);
                }
                int slot;
                if (change.TryGetValue(index, out slot))
                {
                    type = types[slot];
                    body = Unzip(files[slot]);
                }
                WriteInt(output, write, type);
                WriteInt(output, write, body.Length);
                WriteChunk(output, write, body);
            }
            if (input.Position != input.Length)
                throw new InvalidDataException("Uventede data etter modellen.");
            output.Flush(true);
        }
        if (!String.Equals(FileSHA256(destination), targetSHA256, StringComparison.OrdinalIgnoreCase))
        {
            File.Delete(destination);
            throw new InvalidDataException("Kontrollen av den nye modellen feilet. Originalfilene er urort.");
        }
    }
}
