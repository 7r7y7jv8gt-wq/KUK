﻿[CmdletBinding()]
param([string]$ModFolder)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$stage = $null
$backup = $null
$overwriting = $false
$targets = @()

function Read-SafeXml([string]$Path) {
    $doc = New-Object System.Xml.XmlDocument
    $doc.PreserveWhitespace = $true
    $doc.XmlResolver = $null
    $doc.Load($Path)
    return ,$doc
}

function Local-File([string]$Root, [string]$Relative) {
    if ([string]::IsNullOrWhiteSpace($Relative) -or $Relative.StartsWith('$') -or [IO.Path]::IsPathRooted($Relative)) {
        throw 'Modellen peker ikke til en lokal Caddy-fil.'
    }
    $base = [IO.Path]::GetFullPath($Root).TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    $path = [IO.Path]::GetFullPath((Join-Path $Root $Relative))
    if (-not $path.StartsWith($base, [StringComparison]::OrdinalIgnoreCase)) { throw 'Ugyldig filsti i modden.' }
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw ('Finner ikke: ' + $path) }
    return $path
}

try {
    $addon = $PSScriptRoot
    $candidate = Split-Path -Parent $addon
    if ([string]::IsNullOrWhiteSpace($ModFolder) -and
        (Test-Path -LiteralPath (Join-Path $candidate 'modDesc.xml') -PathType Leaf) -and
        (Test-Path -LiteralPath (Join-Path $candidate 'VW_CADDY_2015.xml') -PathType Leaf)) {
        $ModFolder = $candidate
    }
    if ([string]::IsNullOrWhiteSpace($ModFolder)) {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = 'Velg din fungerende Caddy-mappe med blitzbjelka og blitzerne.'
        $dialog.ShowNewFolderButton = $false
        try {
            if ($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { Write-Host 'Avbrutt.'; exit 0 }
            $ModFolder = $dialog.SelectedPath
        } finally { $dialog.Dispose() }
    }
    $ModFolder = (Resolve-Path -LiteralPath $ModFolder).Path
    $vehiclePath = Local-File $ModFolder 'VW_CADDY_2015.xml'
    $descPath = Local-File $ModFolder 'modDesc.xml'
    $vehicle = Read-SafeXml $vehiclePath
    $modelNode = $vehicle.SelectSingleNode('/vehicle/base/filename')
    if ($null -eq $modelNode) { throw 'Mangler modellfil i Caddy-XML-en.' }
    $modelPath = Local-File $ModFolder ($modelNode.InnerText.Trim())
    $model = Read-SafeXml $modelPath
    if ($null -ne $model.SelectSingleNode('/i3D/Scene//*[@name="caddyInteractiveControl"]')) {
        throw 'Denne modellen har allerede IC-dorene fra den forrige patchen. Bruk den fungerende originalversjonen med blitzbjelka, eller gjenopprett de fire filene fra IC_sikkerhetskopi forst.'
    }
    $shapesNode = $model.SelectSingleNode('/i3D/Shapes')
    if ($null -eq $shapesNode) { throw 'Mangler geometri i modellen.' }
    $shapesPath = Local-File (Split-Path -Parent $modelPath) ($shapesNode.GetAttribute('externalShapesFile'))

    Add-Type -Path ([string[]]@(
        (Join-Path $addon 'CurrentShapesMerge.cs'),
        (Join-Path $addon 'CurrentI3DMerge.cs'),
        (Join-Path $addon 'CurrentXmlMerge.cs')
    )) -ReferencedAssemblies @('System.dll', 'System.Core.dll', 'System.Xml.dll')

    $manifest = Get-Content -LiteralPath (Join-Path $addon 'geometry_manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.formatVersion -ne 2) { throw 'Ukjent tilleggspakke.' }
    [int[]]$sourceIds = @($manifest.sources | ForEach-Object { [int]$_.id })
    [string[]]$sourceHashes = @($manifest.sources | ForEach-Object { [string]$_.normalizedSHA256 })
    [int[]]$deltaIds = @($manifest.changes | ForEach-Object { [int]$_.id })
    [int[]]$deltaTypes = @($manifest.changes | ForEach-Object { [int]$_.type })
    [string[]]$deltaFiles = @($manifest.changes | ForEach-Object {
        if ([IO.Path]::GetFileName([string]$_.file) -ne [string]$_.file) { throw 'Ugyldig patchfil.' }
        $path = Join-Path (Join-Path $addon 'modelldata') $_.file
        if ([CurrentCaddyShapesMerge]::FileSHA256($path) -ne $_.gzipSHA256) { throw 'Tilleggspakken er skadet.' }
        $path
    })
    $recipe = Join-Path $addon 'door_recipe.xml'
    [int[]]$currentSourceIds = [CurrentCaddyI3DMerge]::SourceIds($modelPath, $recipe)
    $sourcePaths = @($shapesPath, $modelPath, $vehiclePath, $descPath)
    $beforeHashes = @{}
    foreach ($path in $sourcePaths) { $beforeHashes[$path] = [CurrentCaddyShapesMerge]::FileSHA256($path) }
    Write-Host 'Legger IC til i de eksisterende filene dine ...'
    $plan = [CurrentCaddyShapesMerge]::Prepare($shapesPath, $sourceIds, $currentSourceIds,
        $sourceHashes, $deltaIds, $deltaTypes, $deltaFiles)

    $stage = Join-Path $ModFolder ('.caddy_ic_merge_' + [Guid]::NewGuid().ToString('N'))
    [IO.Directory]::CreateDirectory($stage) | Out-Null
    $newModel = Join-Path $stage 'scene.i3d'
    $newVehicle = Join-Path $stage 'vehicle.xml'
    $newDesc = Join-Path $stage 'modDesc.xml'
    $newShapes = Join-Path $stage 'geometry.shapes'
    $template = Join-Path $stage 'IC_tilpasset.xml'
    $rig = [CurrentCaddyI3DMerge]::Build($modelPath, $recipe, $plan.IdMap, $newModel,
        (Join-Path $addon 'IC_tillegg.xml'), $template)
    $xmlReport = [CurrentXmlMerge]::Build($vehiclePath, $descPath, $newVehicle, $newDesc,
        $template, (Join-Path $addon 'IC_tekster.xml'), $rig.CurrentPathRemaps, $rig.MappingPaths)
    if (-not $xmlReport.OriginalContentPreserved) { throw 'Kunne ikke bevare eksisterende innstillinger.' }
    $newShapesHash = [CurrentCaddyShapesMerge]::Apply($plan, $newShapes)
    $targets = @(
        @{ old = $shapesPath; new = $newShapes },
        @{ old = $modelPath; new = $newModel },
        @{ old = $vehiclePath; new = $newVehicle },
        @{ old = $descPath; new = $newDesc }
    )
    foreach ($target in $targets) {
        if ([CurrentCaddyShapesMerge]::FileSHA256($target.old) -ne $beforeHashes[$target.old]) {
            throw 'En av modfilene ble endret mens tillegget ble laget. Lukk spillet/editoren og prov igjen.'
        }
    }
    $backup = Join-Path $ModFolder ('IC_sikkerhetskopi_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + [Guid]::NewGuid().ToString('N').Substring(0, 6))
    [IO.Directory]::CreateDirectory($backup) | Out-Null
    foreach ($target in $targets) {
        $target.backup = Join-Path $backup ([IO.Path]::GetFileName($target.old))
        [IO.File]::Copy($target.old, $target.backup, $false)
        if ([CurrentCaddyShapesMerge]::FileSHA256($target.backup) -ne $beforeHashes[$target.old]) { throw 'Sikkerhetskopieringen feilet.' }
    }
    $overwriting = $true
    foreach ($target in $targets) { [IO.File]::Replace($target.new, $target.old, $null) }
    @(
        'IC lagt til i eksisterende filer.',
        $rig.Report,
        ('Eksisterende geometrideler bevart uendret: ' + $plan.PreservedEntityCount),
        ('Nye dordeler: ' + $plan.AppendedEntityCount),
        ('SHA256 ny modellgeometri: ' + $newShapesHash),
        ('Sikkerhetskopi: ' + $backup)
    ) | Set-Content -LiteralPath (Join-Path $addon 'Installert_IC.txt') -Encoding UTF8
    Write-Host 'Ferdig! IC er lagt til pa fordorene, skyvedorene og bakluka.' -ForegroundColor Green
    Write-Host 'Aktiver FS25_interactiveControl i lagringen din.'
    Write-Host ('Sikkerhetskopi: ' + $backup)
} catch {
    if ($overwriting) {
        $restored = $true
        foreach ($target in $targets) {
            try { [IO.File]::Copy($target.backup, $target.old, $true) } catch { $restored = $false }
        }
        if ($restored) { Write-Host 'Originalfilene dine er gjenopprettet.' }
        else { Write-Host ('Gjenopprett filene fra: ' + $backup) -ForegroundColor Yellow }
    } else { Write-Host 'Ingen av originalfilene dine er endret.' }
    Write-Host ('Kunne ikke legge til IC: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
} finally {
    if ($stage -and (Test-Path -LiteralPath $stage)) { Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue }
}
