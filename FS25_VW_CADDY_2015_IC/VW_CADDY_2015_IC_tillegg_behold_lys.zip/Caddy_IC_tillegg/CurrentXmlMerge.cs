using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

public sealed class CurrentXmlMergeReport
{
    public int AddedAnimations { get; internal set; }
    public int AddedMappings { get; internal set; }
    public int AddedLabels { get; internal set; }
    public int AddedControllers { get; internal set; }
    public int AddedOutdoorTriggers { get; internal set; }
    public int RemappedReferences { get; internal set; }
    public int PreservedVehicleNodes { get; internal set; }
    public int PreservedModDescNodes { get; internal set; }
    public string OutputVehicle { get; internal set; }
    public string OutputModDesc { get; internal set; }
    public bool OriginalContentPreserved { get; internal set; }
}

// Compatible with Windows PowerShell 5.1 Add-Type and the .NET Framework C# compiler.
// Only door IC additions and explicitly supplied existing node-path replacements
// are applied. Current lights, material settings, configurations and scripts remain
// the source of truth; the template never replaces a current XML document.
public static class CurrentXmlMerge
{
    private static readonly string[] Names = new string[] {
        "caddyIC_frontLeft", "caddyIC_frontRight", "caddyIC_slidingLeft",
        "caddyIC_slidingRight", "caddyIC_tailgate"
    };

    private sealed class OriginalNode
    {
        internal XmlNode Node;
        internal string Name;
        internal string Value;
        internal XmlNodeType Type;
        internal List<XmlNode> Children = new List<XmlNode>();
        internal Dictionary<string, string> Attributes = new Dictionary<string, string>(StringComparer.Ordinal);
    }

    public static CurrentXmlMergeReport Build(
        string currentVehicle, string currentDesc, string outputVehicle, string outputDesc,
        string templateVehicle, string templateDesc,
        Dictionary<string, string> currentPathRemaps,
        Dictionary<string, string> mappingPaths)
    {
        if (mappingPaths == null) throw new ArgumentNullException("mappingPaths");
        if (currentPathRemaps == null) currentPathRemaps = new Dictionary<string, string>();
        CheckOutputPaths(currentVehicle, currentDesc, templateVehicle, templateDesc, outputVehicle, outputDesc);
        foreach (KeyValuePair<string, string> entry in currentPathRemaps)
        {
            ValidateNodePath(entry.Key, "old current path");
            ValidateNodePath(entry.Value, "new current path");
        }
        foreach (string name in Names)
        {
            string path;
            if (!mappingPaths.TryGetValue(name, out path))
                throw new InvalidDataException("Missing generated pivot mapping: " + name);
            ValidateNodePath(path, name);
        }

        XmlDocument vehicle = Read(currentVehicle, "vehicle");
        XmlDocument desc = Read(currentDesc, "modDesc");
        XmlDocument vehicleTemplate = Read(templateVehicle, "vehicle");
        XmlDocument descTemplate = Read(templateDesc, "modDesc");
        List<OriginalNode> originalVehicle = Capture(vehicle);
        List<OriginalNode> originalDesc = Capture(desc);
        string vehicleNewline = Newline(currentVehicle);
        string descNewline = Newline(currentDesc);
        CurrentXmlMergeReport report = new CurrentXmlMergeReport();

        XmlElement currentAnimations = SingleChild(vehicle.DocumentElement, "animations");
        XmlElement currentMappings = SingleChild(vehicle.DocumentElement, "i3dMappings");
        XmlElement currentL10n = SingleChild(desc.DocumentElement, "l10n");
        XmlElement currentIC = SingleChild(vehicle.DocumentElement, "interactiveControl");
        XmlElement templateAnimations = RequiredChild(vehicleTemplate.DocumentElement, "animations");
        XmlElement templateMappings = RequiredChild(vehicleTemplate.DocumentElement, "i3dMappings");
        XmlElement templateControls = RequiredChild(RequiredChild(vehicleTemplate.DocumentElement, "interactiveControl"), "interactiveControls");
        XmlElement templateL10n = RequiredChild(descTemplate.DocumentElement, "l10n");
        XmlElement templateTrigger = RequiredChild(templateControls, "outdoorTrigger");
        List<XmlElement> sourceAnimations = new List<XmlElement>();
        List<XmlElement> sourceMappings = new List<XmlElement>();
        List<XmlElement> sourceControls = new List<XmlElement>();
        List<XmlElement> sourceLabels = new List<XmlElement>();
        HashSet<string> labelNames = new HashSet<string>(StringComparer.Ordinal);
        HashSet<string> controllerNames = new HashSet<string>(Names, StringComparer.Ordinal);

        // All name conflicts and source-template checks are resolved in memory
        // before either output file or output directory is written.
        foreach (string name in Names)
        {
            FailIfNamed(currentAnimations, "animation", "name", name, "animation");
            FailIfNamed(currentMappings, "i3dMapping", "id", name, "i3d mapping");
            sourceAnimations.Add(RequiredNamed(templateAnimations, "animation", "name", name));
            sourceMappings.Add(RequiredNamed(templateMappings, "i3dMapping", "id", name));
            XmlElement foundControl = null;
            foreach (XmlNode node in templateControls.ChildNodes)
            {
                XmlElement candidate = node as XmlElement;
                if (candidate == null || candidate.Name != "interactiveControl") continue;
                XmlElement actor = SingleChild(candidate, "animation");
                if (actor == null || actor.GetAttribute("name") != name) continue;
                if (foundControl != null) throw new InvalidDataException("Duplicate template control: " + name);
                foundControl = candidate;
            }
            if (foundControl == null) throw new InvalidDataException("Missing template control: " + name);
            foreach (string attribute in new string[] { "posText", "negText" })
            {
                string value = foundControl.GetAttribute(attribute);
                if (!value.StartsWith("$l10n_", StringComparison.Ordinal))
                    throw new InvalidDataException("Expected an IC localization reference: " + value);
                string labelName = value.Substring(6);
                if (!labelNames.Add(labelName))
                    throw new InvalidDataException("Template IC labels are not independent: " + labelName);
                FailIfNamed(currentL10n, "text", "name", labelName, "localization");
                sourceLabels.Add(RequiredNamed(templateL10n, "text", "name", labelName));
            }
            foreach (XmlElement point in foundControl.SelectNodes("./clickPoint"))
            {
                if (point.HasAttribute("node") || point.GetAttribute("linkNode") != name)
                    throw new InvalidDataException("IC click points must use their generated pivot as linkNode: " + name);
                string type = point.GetAttribute("type");
                if (type != "INDOOR" && type != "OUTDOOR" && type != "INDOOR_OUTDOOR")
                    throw new InvalidDataException("Invalid IC click point type: " + type);
            }
            sourceControls.Add(foundControl);
        }
        if (sourceLabels.Count != 10) throw new InvalidDataException("Expected ten IC labels");
        if (currentIC != null)
        {
            foreach (XmlElement actor in currentIC.SelectNodes(".//interactiveControl/animation"))
                if (controllerNames.Contains(actor.GetAttribute("name")))
                    throw new InvalidDataException("Current Interactive Control already refers to " + actor.GetAttribute("name") + ". Nothing was written.");
        }

        // Replace only exact current index strings supplied by the I3D merger.
        foreach (XmlElement element in vehicle.SelectNodes("//*"))
        {
            foreach (XmlAttribute attribute in element.Attributes)
            {
                string replacement;
                if (currentPathRemaps.TryGetValue(attribute.Value, out replacement) && replacement != attribute.Value)
                {
                    attribute.Value = replacement;
                    report.RemappedReferences++;
                }
            }
        }
        currentAnimations = EnsureChild(vehicle.DocumentElement, "animations", vehicleNewline);
        currentMappings = EnsureChild(vehicle.DocumentElement, "i3dMappings", vehicleNewline);
        currentL10n = EnsureChild(desc.DocumentElement, "l10n", descNewline);
        for (int i = 0; i < Names.Length; i++)
        {
            Append(currentAnimations, vehicle.ImportNode(sourceAnimations[i], true), vehicleNewline);
            XmlElement mapping = (XmlElement)vehicle.ImportNode(sourceMappings[i], true);
            mapping.SetAttribute("node", mappingPaths[Names[i]]);
            Append(currentMappings, mapping, vehicleNewline);
        }
        foreach (XmlElement sourceLabel in sourceLabels)
            Append(currentL10n, desc.ImportNode(sourceLabel, true), descNewline);
        report.AddedAnimations = Names.Length;
        report.AddedMappings = Names.Length;
        report.AddedLabels = sourceLabels.Count;

        currentIC = EnsureChild(vehicle.DocumentElement, "interactiveControl", vehicleNewline);
        XmlElement direct = SingleChild(currentIC, "interactiveControls");
        XmlElement configurations = SingleChild(currentIC, "interactiveControlConfigurations");
        List<XmlElement> configs = Children(configurations, "interactiveControlConfiguration");
        List<XmlElement> targets = new List<XmlElement>();
        if (direct != null)
            targets.Add(direct); // Direct controls apply to every configuration.
        else if (configs.Count > 0)
        {
            foreach (XmlElement config in configs)
                targets.Add(EnsureChild(config, "interactiveControls", vehicleNewline));
        }
        else
            targets.Add(EnsureChild(currentIC, "interactiveControls", vehicleNewline));

        string triggerLink = ResolveTriggerLink(currentMappings, templateTrigger.GetAttribute("linkNode"));
        foreach (XmlElement target in targets)
        {
            foreach (XmlElement sourceControl in sourceControls)
            {
                Append(target, vehicle.ImportNode(sourceControl, true), vehicleNewline);
                report.AddedControllers++;
            }
            // If direct controls coexist with per-configuration triggers, retain
            // each existing trigger rather than globally overriding it. Fill only
            // configuration groups which have no trigger at all.
            if (target == direct && SingleChild(target, "outdoorTrigger") == null && configs.Count > 0)
            {
                foreach (XmlElement config in configs)
                    AddTriggerIfMissing(EnsureChild(config, "interactiveControls", vehicleNewline), templateTrigger, triggerLink, vehicleNewline, report);
            }
            else
                AddTriggerIfMissing(target, templateTrigger, triggerLink, vehicleNewline, report);
        }

        Verify(originalVehicle, currentPathRemaps, "current vehicle");
        Verify(originalDesc, null, "current modDesc");
        report.PreservedVehicleNodes = originalVehicle.Count;
        report.PreservedModDescNodes = originalDesc.Count;
        report.OriginalContentPreserved = true;

        // Stage both complete XML documents before exposing either output. The
        // current input files are never written by this class.
        outputVehicle = Path.GetFullPath(outputVehicle);
        outputDesc = Path.GetFullPath(outputDesc);
        Directory.CreateDirectory(Path.GetDirectoryName(outputVehicle));
        Directory.CreateDirectory(Path.GetDirectoryName(outputDesc));
        string tempVehicle = outputVehicle + "." + Guid.NewGuid().ToString("N") + ".tmp";
        string tempDesc = outputDesc + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            Save(vehicle, tempVehicle);
            Save(desc, tempDesc);
            Read(tempVehicle, "vehicle");
            Read(tempDesc, "modDesc");
            File.Copy(tempVehicle, outputVehicle, true);
            File.Copy(tempDesc, outputDesc, true);
        }
        finally
        {
            if (File.Exists(tempVehicle)) File.Delete(tempVehicle);
            if (File.Exists(tempDesc)) File.Delete(tempDesc);
        }
        report.OutputVehicle = outputVehicle;
        report.OutputModDesc = outputDesc;
        return report;
    }

    private static void AddTriggerIfMissing(XmlElement controls, XmlElement source, string link, string newline, CurrentXmlMergeReport report)
    {
        if (SingleChild(controls, "outdoorTrigger") != null) return;
        XmlElement trigger = (XmlElement)controls.OwnerDocument.ImportNode(source, true);
        trigger.SetAttribute("linkNode", link);
        Append(controls, trigger, newline);
        report.AddedOutdoorTriggers++;
    }

    private static string ResolveTriggerLink(XmlElement mappings, string desired)
    {
        foreach (XmlElement mapping in Children(mappings, "i3dMapping"))
            if (mapping.GetAttribute("id") == desired && mapping.GetAttribute("node") == "0>") return desired;
        foreach (XmlElement mapping in Children(mappings, "i3dMapping"))
            if (mapping.GetAttribute("node") == "0>") return mapping.GetAttribute("id");
        return "0>";
    }

    private static XmlDocument Read(string path, string rootName)
    {
        XmlDocument result = new XmlDocument();
        result.PreserveWhitespace = true;
        result.XmlResolver = null;
        XmlReaderSettings settings = new XmlReaderSettings();
        settings.DtdProcessing = DtdProcessing.Prohibit;
        settings.XmlResolver = null;
        using (XmlReader reader = XmlReader.Create(path, settings)) result.Load(reader);
        if (result.DocumentElement == null || result.DocumentElement.Name != rootName || result.DocumentElement.NamespaceURI != "")
            throw new InvalidDataException("Expected <" + rootName + "> in " + path);
        return result;
    }

    private static void Save(XmlDocument doc, string path)
    {
        XmlDeclaration declaration = doc.FirstChild as XmlDeclaration;
        XmlWriterSettings settings = new XmlWriterSettings();
        settings.Indent = false;
        settings.NewLineHandling = NewLineHandling.None;
        settings.OmitXmlDeclaration = declaration == null;
        settings.Encoding = declaration != null && declaration.Encoding.Length > 0 ? Encoding.GetEncoding(declaration.Encoding) : new UTF8Encoding(false);
        using (XmlWriter writer = XmlWriter.Create(path, settings)) doc.Save(writer);
    }

    private static void ValidateNodePath(string path, string label)
    {
        if (path == null || !Regex.IsMatch(path, "^[0-9]+>([0-9]+(\\|[0-9]+)*)?$"))
            throw new InvalidDataException("Invalid " + label + ": " + path);
    }

    private static void CheckOutputPaths(string a, string b, string c, string d, string x, string y)
    {
        string xp = Path.GetFullPath(x), yp = Path.GetFullPath(y);
        if (String.Equals(xp, yp, StringComparison.OrdinalIgnoreCase)) throw new IOException("XML outputs must have different paths");
        foreach (string input in new string[] { a, b, c, d })
        {
            string p = Path.GetFullPath(input);
            if (String.Equals(p, xp, StringComparison.OrdinalIgnoreCase) || String.Equals(p, yp, StringComparison.OrdinalIgnoreCase))
                throw new IOException("Current and template XML files must not be used as output paths");
        }
    }

    private static string Newline(string path)
    {
        return File.ReadAllText(path).IndexOf("\r\n", StringComparison.Ordinal) >= 0 ? "\r\n" : "\n";
    }

    private static List<XmlElement> Children(XmlElement parent, string name)
    {
        List<XmlElement> result = new List<XmlElement>();
        if (parent != null)
            foreach (XmlNode node in parent.ChildNodes)
            {
                XmlElement element = node as XmlElement;
                if (element != null && element.Name == name) result.Add(element);
            }
        return result;
    }

    private static XmlElement SingleChild(XmlElement parent, string name)
    {
        List<XmlElement> nodes = Children(parent, name);
        if (nodes.Count > 1) throw new InvalidDataException("Ambiguous duplicate <" + name + "> section");
        return nodes.Count == 0 ? null : nodes[0];
    }

    private static XmlElement RequiredChild(XmlElement parent, string name)
    {
        XmlElement result = SingleChild(parent, name);
        if (result == null) throw new InvalidDataException("Template is missing <" + name + ">");
        return result;
    }

    private static XmlElement RequiredNamed(XmlElement parent, string childName, string attribute, string value)
    {
        XmlElement found = null;
        foreach (XmlElement element in Children(parent, childName))
            if (element.GetAttribute(attribute) == value)
            {
                if (found != null) throw new InvalidDataException("Ambiguous template name: " + value);
                found = element;
            }
        if (found == null) throw new InvalidDataException("Template is missing " + childName + " " + value);
        return found;
    }

    private static void FailIfNamed(XmlElement parent, string childName, string attribute, string value, string label)
    {
        foreach (XmlElement element in Children(parent, childName))
            if (element.GetAttribute(attribute) == value)
                throw new InvalidDataException("Current " + label + " already exists: " + value + ". Nothing was written.");
    }

    private static XmlElement EnsureChild(XmlElement parent, string name, string newline)
    {
        XmlElement result = SingleChild(parent, name);
        if (result != null) return result;
        result = parent.OwnerDocument.CreateElement(name);
        Append(parent, result, newline);
        return result;
    }

    private static string Indent(XmlNode node)
    {
        XmlNode previous = node.PreviousSibling;
        if (previous == null || (previous.NodeType != XmlNodeType.Whitespace && previous.NodeType != XmlNodeType.SignificantWhitespace)) return "";
        string text = previous.Value ?? "";
        int index = text.LastIndexOf('\n');
        string indent = index < 0 ? text : text.Substring(index + 1);
        return indent.Trim(' ', '\t', '\r').Length == 0 ? indent.TrimEnd('\r') : "";
    }

    private static void Append(XmlElement parent, XmlNode child, string newline)
    {
        string parentIndent = Indent(parent), childIndent = parentIndent + "  ";
        foreach (XmlNode existing in parent.ChildNodes)
            if (existing is XmlElement)
            {
                string indent = Indent(existing);
                if (indent.Length > parentIndent.Length) childIndent = indent;
                break;
            }
        XmlNode anchor = parent.LastChild;
        if (anchor == null || (anchor.NodeType != XmlNodeType.Whitespace && anchor.NodeType != XmlNodeType.SignificantWhitespace)) anchor = null;
        XmlWhitespace leading = parent.OwnerDocument.CreateWhitespace(newline + childIndent);
        if (anchor != null)
        {
            parent.InsertBefore(leading, anchor);
            parent.InsertBefore(child, anchor);
        }
        else
        {
            parent.AppendChild(leading);
            parent.AppendChild(child);
            parent.AppendChild(parent.OwnerDocument.CreateWhitespace(newline + parentIndent));
        }
    }

    private static List<OriginalNode> Capture(XmlDocument doc)
    {
        List<OriginalNode> result = new List<OriginalNode>();
        CaptureNode(doc, result);
        return result;
    }

    private static void CaptureNode(XmlNode node, List<OriginalNode> result)
    {
        OriginalNode entry = new OriginalNode();
        entry.Node = node; entry.Name = node.Name; entry.Type = node.NodeType; entry.Value = node.Value;
        if (node.Attributes != null)
            foreach (XmlAttribute attribute in node.Attributes) entry.Attributes.Add(attribute.Name, attribute.Value);
        foreach (XmlNode child in node.ChildNodes) entry.Children.Add(child);
        result.Add(entry);
        foreach (XmlNode child in node.ChildNodes) CaptureNode(child, result);
    }

    private static void Verify(List<OriginalNode> entries, Dictionary<string, string> remaps, string label)
    {
        foreach (OriginalNode entry in entries)
        {
            XmlNode node = entry.Node;
            if (node.Name != entry.Name || node.NodeType != entry.Type || node.Value != entry.Value)
                throw new InvalidDataException("An original " + label + " node was unexpectedly changed");
            if ((node.Attributes == null ? 0 : node.Attributes.Count) != entry.Attributes.Count)
                throw new InvalidDataException("Original " + label + " attributes were unexpectedly added or removed");
            foreach (KeyValuePair<string, string> attribute in entry.Attributes)
            {
                string expected = attribute.Value, replacement;
                if (remaps != null && remaps.TryGetValue(expected, out replacement)) expected = replacement;
                if (node.Attributes[attribute.Key] == null || node.Attributes[attribute.Key].Value != expected)
                    throw new InvalidDataException("Original " + label + " attribute was unexpectedly changed: " + attribute.Key);
            }
            int next = 0;
            foreach (XmlNode current in node.ChildNodes)
                if (next < entry.Children.Count && Object.ReferenceEquals(current, entry.Children[next])) next++;
            if (next != entry.Children.Count)
                throw new InvalidDataException("Original " + label + " children were removed or reordered");
        }
    }
}
