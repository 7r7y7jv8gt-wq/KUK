// Selectively add the Caddy door rig to the user's current scene.
// Existing light, material, texture and vehicle data come from the current files.
using System;
using System.IO;
using System.Xml;
using System.Globalization;
using System.Collections.Generic;

public static class CurrentCaddyI3DMerge
{
    static readonly CultureInfo CI = CultureInfo.InvariantCulture;
    public sealed class Result
    {
        public Dictionary<string,string> CurrentPathRemaps = new Dictionary<string,string>();
        public Dictionary<string,string> MappingPaths = new Dictionary<string,string>();
        public string Report;
    }
    static XmlDocument Load(string path) { var d=new XmlDocument(); d.PreserveWhitespace=true; d.XmlResolver=null; d.Load(path); return d; }
    static string A(XmlElement n,string a) { return n.GetAttribute(a); }
    static List<XmlElement> Children(XmlNode parent)
    { var r=new List<XmlElement>(); foreach(XmlNode n in parent.ChildNodes) if(n is XmlElement) r.Add((XmlElement)n); return r; }
    static List<XmlElement> Nodes(XmlNode parent)
    { var r=new List<XmlElement>(); foreach(var n in Children(parent)) {if(n.HasAttribute("nodeId"))r.Add(n); r.AddRange(Nodes(n));} return r; }
    static XmlElement Find(XmlDocument scene,XmlElement spec)
    {
        string id=A(spec,"originalNodeId"),name=A(spec,"nodeName"),tag=A(spec,"tag");
        XmlElement byId=null; var candidates=new List<XmlElement>();
        foreach(var n in Nodes(scene.SelectSingleNode("/i3D/Scene")))
        { if(n.Name!=tag || A(n,"name")!=name)continue; candidates.Add(n); if(A(n,"nodeId")==id)byId=n; }
        // Ancestor names distinguish e.g. repeated Body containers.
        string expected=A(spec,"namePath");
        foreach(var n in candidates) if(NamePath(n)==expected)return n;
        if(byId!=null)return byId;
        if(candidates.Count==1)return candidates[0];
        throw new InvalidDataException("Finner ikke entydig dordel i gjeldende modell: "+name+". Ingen originalfiler er endret.");
    }
    static string NamePath(XmlElement n)
    { var names=new List<string>(); XmlNode p=n; while(p is XmlElement && p.Name!="Scene") {names.Insert(0,((XmlElement)p).GetAttribute("name"));p=p.ParentNode;}return String.Join("/",names.ToArray()); }
    public static int[] SourceIds(string currentModel,string recipeFile)
    { var d=Load(currentModel);var recipe=Load(recipeFile);var ids=new List<int>();foreach(XmlElement s in recipe.SelectNodes("/recipe/sources/source"))ids.Add(Int32.Parse(A(Find(d,s),"shapeId"),CI));return ids.ToArray(); }

    // Column-vector affine matrices, GIANTS Euler order Rz*Ry*Rx.
    static double[] Id() {return new double[]{1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};}
    static double[] Mul(double[] a,double[] b)
    {var c=new double[16];for(int r=0;r<4;r++)for(int k=0;k<4;k++)for(int j=0;j<4;j++)c[r*4+j]+=a[r*4+k]*b[k*4+j];return c;}
    static double[] Inverse(double[] a)
    {
        double x=a[0],y=a[1],z=a[2],u=a[4],v=a[5],w=a[6],p=a[8],q=a[9],r=a[10];
        double det=x*(v*r-w*q)-y*(u*r-w*p)+z*(u*q-v*p);
        if(Math.Abs(det)<1e-12)throw new InvalidDataException("Ugyldig modelltransformasjon.");
        var b=Id();b[0]=(v*r-w*q)/det;b[1]=(z*q-y*r)/det;b[2]=(y*w-z*v)/det;
        b[4]=(w*p-u*r)/det;b[5]=(x*r-z*p)/det;b[6]=(z*u-x*w)/det;
        b[8]=(u*q-v*p)/det;b[9]=(y*p-x*q)/det;b[10]=(x*v-y*u)/det;
        b[3]=-(b[0]*a[3]+b[1]*a[7]+b[2]*a[11]);b[7]=-(b[4]*a[3]+b[5]*a[7]+b[6]*a[11]);b[11]=-(b[8]*a[3]+b[9]*a[7]+b[10]*a[11]);return b;
    }
    static double[] V(string text,string fallback)
    {string[] s=(String.IsNullOrWhiteSpace(text)?fallback:text).Split(new char[]{' ','\t','\r','\n'},StringSplitOptions.RemoveEmptyEntries);if(s.Length!=3)throw new InvalidDataException("Ugyldig 3D-vektor.");return new double[]{Double.Parse(s[0],CI),Double.Parse(s[1],CI),Double.Parse(s[2],CI)};}
    static double[] Local(XmlElement n)
    {
        double[] t=V(A(n,"translation"),"0 0 0"),r=V(A(n,"rotation"),"0 0 0"),s=V(A(n,"scale"),"1 1 1");
        double a=r[0]*Math.PI/180,b=r[1]*Math.PI/180,c=r[2]*Math.PI/180;
        double ca=Math.Cos(a),sa=Math.Sin(a),cb=Math.Cos(b),sb=Math.Sin(b),cc=Math.Cos(c),sc=Math.Sin(c);
        var m=Id();m[0]=cc*cb*s[0];m[1]=(cc*sb*sa-sc*ca)*s[1];m[2]=(cc*sb*ca+sc*sa)*s[2];m[3]=t[0];
        m[4]=sc*cb*s[0];m[5]=(sc*sb*sa+cc*ca)*s[1];m[6]=(sc*sb*ca-cc*sa)*s[2];m[7]=t[1];
        m[8]=-sb*s[0];m[9]=cb*sa*s[1];m[10]=cb*ca*s[2];m[11]=t[2];return m;
    }
    static double[] World(XmlElement n)
    { if(n.ParentNode is XmlElement && ((XmlElement)n.ParentNode).HasAttribute("nodeId"))return Mul(World((XmlElement)n.ParentNode),Local(n));return Local(n); }
    static string Vec(double[] v) {return v[0].ToString("G16",CI)+" "+v[1].ToString("G16",CI)+" "+v[2].ToString("G16",CI);}
    static double[] Position(double[] m,double[] p)
    {return new double[]{m[0]*p[0]+m[1]*p[1]+m[2]*p[2]+m[3],m[4]*p[0]+m[5]*p[1]+m[6]*p[2]+m[7],m[8]*p[0]+m[9]*p[1]+m[10]*p[2]+m[11]};}
    static double[] RotationOnly(double[] m)
    {var r=Id();for(int c=0;c<3;c++){double s=Math.Sqrt(m[c]*m[c]+m[4+c]*m[4+c]+m[8+c]*m[8+c]);for(int row=0;row<3;row++)r[row*4+c]=m[row*4+c]/s;}return r;}
    static double[] Euler(double[] r)
    {double y=Math.Asin(Math.Max(-1,Math.Min(1,-r[8]))),x,z;if(Math.Abs(Math.Cos(y))>1e-8){x=Math.Atan2(r[9],r[10]);z=Math.Atan2(r[4],r[0]);}else{x=Math.Atan2(-r[6],r[5]);z=0;}return new double[]{x*180/Math.PI,y*180/Math.PI,z*180/Math.PI};}
    static void SetMatrix(XmlElement n,double[] m)
    {
        var s=new double[3];for(int c=0;c<3;c++)s[c]=Math.Sqrt(m[c]*m[c]+m[4+c]*m[4+c]+m[8+c]*m[8+c]);
        n.SetAttribute("translation",Vec(new double[]{m[3],m[7],m[11]}));
        n.SetAttribute("rotation",Vec(Euler(RotationOnly(m))));n.SetAttribute("scale",Vec(s));
        double[] actual=Local(n);for(int i=0;i<16;i++)if(Math.Abs(actual[i]-m[i])>1e-7)throw new InvalidDataException("Modellen har en transformasjon som ikke kan flyttes trygt.");
    }
    static void MapPaths(XmlNode parent,string prefix,Dictionary<XmlElement,string> map)
    {int index=0;foreach(var n in Children(parent)){if(!n.HasAttribute("nodeId"))continue;string path=prefix==null?index+">":prefix+(prefix.EndsWith(">")?"":"|")+index;map[n]=path;MapPaths(n,path,map);index++;}}
    static XmlElement New(XmlDocument d,string tag,string name,int id)
    {var n=d.CreateElement(tag);n.SetAttribute("name",name);n.SetAttribute("nodeId",id.ToString(CI));return n;}
    static void Move(XmlDocument d,XmlElement node,XmlElement pivot,double[] originalWorld,ref int next)
    {
        var marker=New(d,"TransformGroup",A(node,"name")+"_icOriginalPosition",next++);
        foreach(string attr in new string[]{"translation","rotation","scale"})if(node.HasAttribute(attr))marker.SetAttribute(attr,A(node,attr));
        node.ParentNode.ReplaceChild(marker,node);pivot.AppendChild(node);SetMatrix(node,Mul(Inverse(World(pivot)),originalWorld));
    }
    static void Save(XmlDocument d,string file)
    {var settings=new XmlWriterSettings();settings.Encoding=new System.Text.UTF8Encoding(false);settings.Indent=false;using(var w=XmlWriter.Create(file,settings))d.Save(w);}
    public static Result Build(string currentModel,string recipeFile,Dictionary<int,int> shapeIds,string outputModel,string templateVehicle,string adjustedTemplateVehicle)
    {
        var d=Load(currentModel);var recipe=Load(recipeFile);XmlNode scene=d.SelectSingleNode("/i3D/Scene");
        foreach(var n in Nodes(scene))if(A(n,"name")=="caddyInteractiveControl")throw new InvalidDataException("IC-dorene er allerede lagt til. Bruk den fungerende originalversjonen med lysene du vil beholde.");
        var originals=Nodes(scene);var paths=new Dictionary<XmlElement,string>();MapPaths(scene,null,paths);
        var worlds=new Dictionary<XmlElement,double[]>();int next=1;
        foreach(var n in originals){worlds[n]=World(n);int id=Int32.Parse(A(n,"nodeId"),CI);if(id>=next)next=id+1;}
        var sourceNodes=new Dictionary<int,XmlElement>();
        foreach(XmlElement s in recipe.SelectNodes("/recipe/sources/source"))sourceNodes.Add(Int32.Parse(A(s,"baselineShapeId"),CI),Find(d,s));
        XmlElement body=sourceNodes[257],component=body;
        while(component.ParentNode!=scene)component=(XmlElement)component.ParentNode;
        XmlElement rig=New(d,"TransformGroup","caddyInteractiveControl",next++);component.AppendChild(rig);
        double[] baseline=Id();baseline[7]=-2.158;baseline[11]=.328;
        double[] alignment=Mul(worlds[body],Inverse(baseline));
        double[] rigAlignment=Mul(Inverse(World(rig)),alignment);
        var pivots=new Dictionary<string,XmlElement>();
        foreach(XmlElement p in recipe.SelectNodes("/recipe/pivots/pivot"))
        {
            var pivot=New(d,"TransformGroup","caddyIC_"+A(p,"key"),next++);rig.AppendChild(pivot);
            var original=Id();double[] t=V(A(p,"translation"),"0 0 0");original[3]=t[0];original[7]=t[1];original[11]=t[2];
            SetMatrix(pivot,Mul(rigAlignment,original));pivots.Add(A(p,"key"),pivot);
        }
        foreach(XmlElement part in recipe.SelectNodes("/recipe/parts/part"))
        {
            int source=Int32.Parse(A(part,"source"),CI),shape=Int32.Parse(A(part,"shape"),CI);string group=A(part,"group");
            XmlElement src=sourceNodes[source],target;
            if(shape==source)target=src;
            else
            {
                target=d.CreateElement("Shape");foreach(XmlAttribute a in src.Attributes)target.SetAttribute(a.Name,a.Value);
                target.SetAttribute("nodeId",(next++).ToString(CI));target.SetAttribute("name","caddyIC_"+group+"_"+A(src,"name"));
            }
            target.SetAttribute("shapeId",shapeIds[shape].ToString(CI));
            if(group!="static")
            {if(shape==source)Move(d,target,pivots[group],worlds[src],ref next);else{pivots[group].AppendChild(target);SetMatrix(target,Mul(Inverse(World(pivots[group])),worlds[src]));}}
        }
        foreach(XmlElement spec in recipe.SelectNodes("/recipe/moves/move"))
        {XmlElement n=Find(d,spec);Move(d,n,pivots[A(spec,"group")],worlds[n],ref next);}
        var now=new Dictionary<XmlElement,string>();MapPaths(scene,null,now);var result=new Result();
        double maxError=0;
        foreach(var n in originals)
        {
            if(!now.ContainsKey(n))throw new InvalidDataException("En opprinnelig modellnode ble borte.");
            double[] actual=World(n);for(int i=0;i<16;i++)maxError=Math.Max(maxError,Math.Abs(actual[i]-worlds[n][i]));
            if(paths[n]!=now[n])result.CurrentPathRemaps.Add(paths[n],now[n]);
        }
        if(maxError>1e-7)throw new InvalidDataException("Lukket dorplassering ville blitt endret.");
        foreach(var pair in pivots)result.MappingPaths.Add("caddyIC_"+pair.Key,now[pair.Value]);
        // Adjust the copied IC animation template if the existing body was translated/scaled.
        var template=Load(templateVehicle);double[] basis=RotationOnly(rigAlignment);
        foreach(XmlElement trigger in template.SelectNodes("/vehicle/interactiveControl/interactiveControls/outdoorTrigger"))trigger.SetAttribute("linkNode",now[component]);
        foreach(XmlElement part in template.SelectNodes("/vehicle/animations/animation/part"))
        {
            foreach(string attr in new string[]{"startTrans","endTrans"})if(part.HasAttribute(attr))part.SetAttribute(attr,Vec(Position(rigAlignment,V(A(part,attr),"0 0 0"))));
            foreach(string attr in new string[]{"startRot","endRot"})if(part.HasAttribute(attr))
            {var rotation=template.CreateElement("TransformGroup");rotation.SetAttribute("rotation",A(part,attr));part.SetAttribute(attr,Vec(Euler(Mul(basis,Local(rotation)))));}
        }
        // Click-point offsets are local to a pivot and retain the authored positions.
        result.Report="Original nodes retained: "+originals.Count+"; changed existing paths: "+result.CurrentPathRemaps.Count+"; closed pose error: "+maxError.ToString("G6",CI);
        Save(template,adjustedTemplateVehicle);Save(d,outputModel);return result;
    }
}
