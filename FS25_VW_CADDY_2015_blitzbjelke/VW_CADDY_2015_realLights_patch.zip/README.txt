PATCH ONLY — not a complete mod. Back up the original mod, replace VW_CADDY_2015.i3d and VW_CADDY_2015.xml inside it, and keep all other original files.
