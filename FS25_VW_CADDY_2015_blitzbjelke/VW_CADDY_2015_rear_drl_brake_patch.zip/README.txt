PATCH ONLY — replace VW_CADDY_2015.xml inside the complete original mod. Rear red diodes: intensity 40 on light type 1; intensity 80 on brake light type 2. Keep all other original mod files.
