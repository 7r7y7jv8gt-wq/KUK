VISUAL IMPORT TEST ONLY - NOT A COMPLETE FS25 MAP

1. Extract your ORIGINAL FS19_Walchen_2K20.zip into a folder. This supplies original geometry and textures; no FS19 game installation is needed for this selected test.
2. Copy walchen_local_buildings_test.i3d from this package into the original map folder's maps subfolder, alongside map.i3d and map.i3d.shapes. Do not overwrite either original file.
3. Open a COPY of your editor-resaved FS25 draft's map/map.i3d in GIANTS Editor 10.0.14, then use File > Import to select walchen_local_buildings_test.i3d from the original FS19 folder's maps subfolder.
4. Send the editor log and a screenshot. Do not overwrite your existing working draft until compatibility is checked.

This imports only complete source subgroups whose directly referenced resources exist in the original archive or your FS25 filename catalog. Resource names are checked; shader behavior and old binary shape format still require the editor test. Many original buildings are omitted because their FS19 textures are unavailable. No full conversion is claimed. Legacy runtime callbacks, sound, lights and shape collision flags are excluded for this visual test; these functions must be rebuilt separately.

Original coordinates and parent transforms are preserved. The map.i3d.shapes file required by this test belongs to the original Walchen 1.2.0.0 archive, not the FS25 draft. Original author: Austro Modding Gemeinschaft.
