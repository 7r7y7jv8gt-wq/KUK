-- Spawn the real FS25 Kaercher vehicle once; native vehicle/hand-tool code owns
-- washing, effects, sound, controls, networking and normal vehicle persistence.
NorskLaaveWasher = {}
NorskLaaveWasher.SPEC_NAME = g_currentModName .. ".norskLaaveWasher"
NorskLaaveWasher.SPEC_TABLE_NAME = "spec_" .. NorskLaaveWasher.SPEC_NAME

function NorskLaaveWasher.prerequisitesPresent(specializations)
    return true
end

function NorskLaaveWasher.registerXMLPaths(schema, basePath)
    schema:setXMLSpecializationType("NorskLaaveWasher")
    -- Reuse the published placeableVehicle XML structure, without the stock
    -- PlaceableVehicle specialization (its register override deletes wrappers).
    schema:register(XMLValueType.FILENAME, "placeable.placeableVehicle.vehicle(?)#xmlFilename", "Stock washer vehicle XML")
    schema:register(XMLValueType.NODE_INDEX, "placeable.placeableVehicle.vehicle(?)#linkNode", "Washer's initial position")
    schema:setXMLSpecializationType()
end

function NorskLaaveWasher.registerSavegameXMLPaths(schema, basePath)
    schema:register(XMLValueType.BOOL, basePath .. "#spawned", "Washer has been supplied for this barn", false)
    schema:register(XMLValueType.STRING, basePath .. "#vehicleUniqueId", "Native vehicle unique id")
end

function NorskLaaveWasher.registerFunctions(placeableType)
    SpecializationUtil.registerFunction(placeableType, "spawnNorskLaaveWasher", NorskLaaveWasher.spawnNorskLaaveWasher)
    SpecializationUtil.registerFunction(placeableType, "onNorskLaaveWasherLoaded", NorskLaaveWasher.onNorskLaaveWasherLoaded)
end

function NorskLaaveWasher.registerEventListeners(placeableType)
    for _, event in ipairs({"onLoad", "onFinalizePlacement", "onUpdate", "onDelete"}) do
        SpecializationUtil.registerEventListener(placeableType, event, NorskLaaveWasher)
    end
end

function NorskLaaveWasher:onLoad(savegame)
    local spec = self[NorskLaaveWasher.SPEC_TABLE_NAME]
    spec.spawned, spec.pending, spec.armed, spec.deleted = false, false, false, false
    spec.attempts, spec.waitMs = 0, 1000
    spec.filename = self.xmlFile:getValue("placeable.placeableVehicle.vehicle(0)#xmlFilename", nil, self.baseDirectory)
    spec.spawnNode = self.xmlFile:getValue("placeable.placeableVehicle.vehicle(0)#linkNode", nil, self.components, self.i3dMappings)
    if savegame ~= nil then
        local key = savegame.key .. "." .. NorskLaaveWasher.SPEC_NAME
        spec.spawned = savegame.xmlFile:getValue(key .. "#spawned", false)
        spec.vehicleUniqueId = savegame.xmlFile:getValue(key .. "#vehicleUniqueId")
    end
end

function NorskLaaveWasher:onFinalizePlacement()
    local spec = self[NorskLaaveWasher.SPEC_TABLE_NAME]
    if self.isServer and g_iconGenerator == nil and not spec.spawned then
        spec.armed = true
        self:raiseActive()
    end
end

function NorskLaaveWasher:onUpdate(dt)
    local spec = self[NorskLaaveWasher.SPEC_TABLE_NAME]
    if not self.isServer or not spec.armed or spec.spawned or spec.deleted or spec.pending or spec.attempts >= 3 then
        return
    end
    -- Existing placed barns also finalize on savegame load. Delay a moment and
    -- wait for farm ownership, so upgrades receive one washer as well.
    if (self:getOwnerFarmId() or 0) <= 0 then
        self:raiseActive()
        return
    end
    spec.waitMs = spec.waitMs - dt
    if spec.waitMs > 0 then
        self:raiseActive()
        return
    end
    self:spawnNorskLaaveWasher()
end

function NorskLaaveWasher:spawnNorskLaaveWasher()
    local spec = self[NorskLaaveWasher.SPEC_TABLE_NAME]
    if not self.isServer or spec.spawned or spec.pending or spec.deleted or spec.attempts >= 3 then return end
    spec.attempts = spec.attempts + 1
    if spec.filename == nil or spec.spawnNode == nil then
        Logging.error("NorskLaave: missing washer filename or spawn node; no washer spawned")
        spec.attempts = 3
        return
    end
    local data = VehicleLoadingData.new()
    data:setFilename(spec.filename)
    if not data.isValid then
        Logging.error("NorskLaave: stock pressure washer is not available: %s", spec.filename)
        spec.attempts = 3
        return
    end
    data:setOwnerFarmId(self:getOwnerFarmId())
    data:setPropertyState(VehiclePropertyState.OWNED)
    data:setSpawnNode(spec.spawnNode)
    data:setIgnoreShopOffset(true)
    data:setIsRegistered(true)
    data:setIsSaved(true)
    spec.pending = true
    data:load(self.onNorskLaaveWasherLoaded, self)
end

function NorskLaaveWasher:onNorskLaaveWasherLoaded(vehicles, loadingState)
    local spec = self[NorskLaaveWasher.SPEC_TABLE_NAME]
    spec.pending = false
    if spec.deleted or self:getIsBeingDeleted() then
        if loadingState == VehicleLoadingState.OK and vehicles ~= nil then
            for _, vehicle in ipairs(vehicles) do vehicle:delete() end
        end
        return
    end
    if loadingState == VehicleLoadingState.OK and vehicles ~= nil and #vehicles > 0 then
        spec.spawned = true
        spec.vehicleUniqueId = vehicles[1]:getUniqueId()
        spec.armed = false
        Logging.info("NorskLaave: supplied stock Kaercher pressure washer (%s)", tostring(spec.vehicleUniqueId))
    else
        Logging.warning("NorskLaave: pressure washer load failed (attempt %d of 3)", spec.attempts)
        spec.waitMs = 10000
        self:raiseActive()
    end
end

function NorskLaaveWasher:saveToXMLFile(xmlFile, key, usedModNames)
    local spec = self[NorskLaaveWasher.SPEC_TABLE_NAME]
    xmlFile:setValue(key .. "#spawned", spec.spawned)
    if spec.vehicleUniqueId ~= nil then xmlFile:setValue(key .. "#vehicleUniqueId", spec.vehicleUniqueId) end
end

function NorskLaaveWasher:onDelete()
    local spec = self[NorskLaaveWasher.SPEC_TABLE_NAME]
    spec.deleted = true
    -- An already supplied washer is a normal saved, movable farm vehicle.
    -- Keep it when the barn is sold, including if the player moved it elsewhere.
end
