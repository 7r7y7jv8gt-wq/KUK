-- Supply the native workshop menu from the whole room, including vehicles whose
-- physics trigger-enter event was missed during loading. No global hooks/input/UI.
NorskLaaveWorkshopArea = {}
NorskLaaveWorkshopArea.SPEC_NAME = g_currentModName .. ".norskLaaveWorkshopArea"
NorskLaaveWorkshopArea.SPEC_TABLE_NAME = "spec_" .. NorskLaaveWorkshopArea.SPEC_NAME
NorskLaaveWorkshopArea.POLL_INTERVAL_MS = 500
NorskLaaveWorkshopArea.MIN_X, NorskLaaveWorkshopArea.MAX_X = -15.90, -8.66
NorskLaaveWorkshopArea.MIN_Z, NorskLaaveWorkshopArea.MAX_Z = -6.95, 6.95
-- Some custom vehicles place their component origin slightly below the floor.
NorskLaaveWorkshopArea.MIN_Y, NorskLaaveWorkshopArea.MAX_Y = -.50, 10

function NorskLaaveWorkshopArea.prerequisitesPresent(specializations)
    return true
end

function NorskLaaveWorkshopArea.registerEventListeners(placeableType)
    for _, event in ipairs({"onLoad", "onFinalizePlacement", "onUpdate", "onDelete"}) do
        SpecializationUtil.registerEventListener(placeableType, event, NorskLaaveWorkshopArea)
    end
end

local function isDeleted(vehicle)
    return vehicle == nil or (vehicle.getIsBeingDeleted ~= nil and vehicle:getIsBeingDeleted())
end

local function pointInside(placeable, node)
    if node == nil or node == 0 or not entityExists(node) then return false end
    local x, y, z = getWorldTranslation(node)
    x, y, z = worldToLocal(placeable.rootNode, x, y, z)
    local S = NorskLaaveWorkshopArea
    return x >= S.MIN_X and x <= S.MAX_X and y >= S.MIN_Y and y <= S.MAX_Y
        and z >= S.MIN_Z and z <= S.MAX_Z
end

function NorskLaaveWorkshopArea.isVehicleInside(placeable, vehicle)
    if isDeleted(vehicle) or placeable.rootNode == nil or not entityExists(placeable.rootNode) then return false end
    if pointInside(placeable, vehicle.rootNode) then return true end
    for _, component in ipairs(vehicle.components or {}) do
        if pointInside(placeable, component.node) then return true end
    end
    return false
end

local function getRoot(vehicle)
    if vehicle.getRootVehicle ~= nil then return vehicle:getRootVehicle() or vehicle end
    return vehicle.rootVehicle or vehicle
end

local function listSignature(vehicles)
    local ids = {}
    for _, vehicle in ipairs(vehicles) do ids[#ids + 1] = tostring(vehicle.rootNode) end
    return table.concat(ids, ":")
end

function NorskLaaveWorkshopArea.collectVehicles(placeable, sellingPoint, nativeVehicles)
    local mission = g_currentMission
    if mission == nil or mission.vehicleSystem == nil then return {} end
    local farmId = mission:getFarmId()
    if farmId == nil or farmId == FarmManager.SPECTATOR_FARM_ID then return {} end
    local owner = sellingPoint.getOwnerFarmId ~= nil and sellingPoint:getOwnerFarmId() or placeable:getOwnerFarmId()
    if owner ~= AccessHandler.EVERYONE and owner ~= farmId then return {} end

    local result, added = {}, {}
    local function add(vehicle, root)
        if isDeleted(vehicle) or added[vehicle] or vehicle.rootNode == nil then return end
        if vehicle.getOwnerFarmId == nil or vehicle:getOwnerFarmId() ~= farmId then return end
        -- Preserve the same eligibility used by the original FS25 workshop.
        if vehicle.getShowInVehiclesOverview == nil or not vehicle:getShowInVehiclesOverview() then return end
        if not NorskLaaveWorkshopArea.isVehicleInside(placeable, vehicle)
            and not NorskLaaveWorkshopArea.isVehicleInside(placeable, root) then return end
        added[vehicle] = true
        result[#result + 1] = vehicle
    end
    local seenChains = {}
    local function visit(vehicle)
        if isDeleted(vehicle) then return end
        local root = getRoot(vehicle)
        add(vehicle, root)
        if root == nil or seenChains[root] then return end
        seenChains[root] = true
        add(root, root)
        if root.getChildVehicles ~= nil then
            for _, child in ipairs(root:getChildVehicles() or {}) do add(child, root) end
        end
    end
    for _, vehicle in ipairs(nativeVehicles or {}) do visit(vehicle) end
    -- This registry contains fully registered FS25 vehicles, not raw shape IDs.
    for _, vehicle in pairs(mission.vehicleSystem.vehicles or {}) do visit(vehicle) end
    table.sort(result, function(a, b) return a.rootNode < b.rootNode end)
    return result
end

local function restorePoint(spec)
    local point = spec.sellingPoint
    if point ~= nil and point.determineCurrentVehicles == spec.determineWrapper then
        point.determineCurrentVehicles = spec.originalDetermine
    end
    spec.sellingPoint, spec.determineWrapper, spec.originalDetermine = nil, nil, nil
    spec.lastSignature = nil
end

local function attachPoint(placeable, spec)
    local point = placeable.spec_workshop ~= nil and placeable.spec_workshop.sellingPoint or nil
    if point == nil or point.determineCurrentVehicles == nil then return false end
    if spec.sellingPoint == point and point.determineCurrentVehicles == spec.determineWrapper then return true end
    restorePoint(spec)
    spec.sellingPoint = point
    local originalDetermine = point.determineCurrentVehicles
    spec.originalDetermine = originalDetermine
    spec.determineWrapper = function(sellingPoint)
        local native = originalDetermine(sellingPoint)
        local vehicles = NorskLaaveWorkshopArea.collectVehicles(placeable, sellingPoint, native)
        -- An openMenu/native trigger update immediately consumes this exact list.
        if not spec.inRefresh then spec.lastSignature = listSignature(vehicles) end
        return vehicles
    end
    point.determineCurrentVehicles = spec.determineWrapper
    return true
end

function NorskLaaveWorkshopArea:onLoad(savegame)
    local spec = self[NorskLaaveWorkshopArea.SPEC_TABLE_NAME]
    spec.elapsedMs, spec.deleted = NorskLaaveWorkshopArea.POLL_INTERVAL_MS, false
    spec.inRefresh = false
    spec.lastSignature = nil
    if self.isClient then attachPoint(self, spec) end
end

function NorskLaaveWorkshopArea:onFinalizePlacement()
    if self.isClient then self:raiseActive() end
end

function NorskLaaveWorkshopArea:onUpdate(dt)
    if not self.isClient then return end
    local spec = self[NorskLaaveWorkshopArea.SPEC_TABLE_NAME]
    if spec.deleted then return end
    self:raiseActive()
    spec.elapsedMs = spec.elapsedMs + dt
    if spec.elapsedMs < NorskLaaveWorkshopArea.POLL_INTERVAL_MS then return end
    spec.elapsedMs = 0
    if not attachPoint(self, spec) then return end
    -- Use the same native update API as VehicleSellingPoint's trigger callback.
    -- It ignores another selling point; currentGuiName is public in FS25 VehicleSystem.
    if g_gui == nil or g_gui.currentGuiName ~= "WorkshopScreen" or g_workshopScreen == nil then return end
    local point = spec.sellingPoint
    spec.inRefresh = true
    local native = spec.originalDetermine(point)
    spec.inRefresh = false
    local vehicles = NorskLaaveWorkshopArea.collectVehicles(self, point, native)
    local signature = listSignature(vehicles)
    if signature ~= spec.lastSignature then
        spec.lastSignature = signature
        g_workshopScreen:updateVehicles(point, vehicles)
    end
end

function NorskLaaveWorkshopArea:onDelete()
    local spec = self[NorskLaaveWorkshopArea.SPEC_TABLE_NAME]
    if spec ~= nil then spec.deleted = true; restorePoint(spec) end
end
