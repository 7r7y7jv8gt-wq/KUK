-- Keep the original FS25 workshop action available near the measured bench point.
-- The stock workshop still owns its menu, input handling, permissions and vehicles.
NorskLaaveWorkshopInteraction = {}
NorskLaaveWorkshopInteraction.SPEC_NAME = g_currentModName .. ".norskLaaveWorkshopInteraction"
NorskLaaveWorkshopInteraction.SPEC_TABLE_NAME = "spec_" .. NorskLaaveWorkshopInteraction.SPEC_NAME
NorskLaaveWorkshopInteraction.POLL_INTERVAL_MS = 150
NorskLaaveWorkshopInteraction.RADIUS = 1.5
NorskLaaveWorkshopInteraction.HEIGHT_TOLERANCE = 3

function NorskLaaveWorkshopInteraction.prerequisitesPresent(specializations)
    return true
end

function NorskLaaveWorkshopInteraction.registerEventListeners(placeableType)
    for _, event in ipairs({"onLoad", "onFinalizePlacement", "onUpdate", "onDelete"}) do
        SpecializationUtil.registerEventListener(placeableType, event, NorskLaaveWorkshopInteraction)
    end
end

local function removeRegistered(spec)
    local mission = g_currentMission
    local system = mission ~= nil and mission.activatableObjectsSystem or nil
    if spec.registeredActivatable ~= nil and system ~= nil then
        system:removeActivatable(spec.registeredActivatable)
    end
    spec.registeredActivatable = nil
end

function NorskLaaveWorkshopInteraction:onLoad(savegame)
    local spec = self[NorskLaaveWorkshopInteraction.SPEC_TABLE_NAME]
    spec.elapsedMs = NorskLaaveWorkshopInteraction.POLL_INTERVAL_MS
    spec.registeredActivatable = nil
    spec.deleted = false
end

function NorskLaaveWorkshopInteraction:onFinalizePlacement()
    if self.isClient then
        self:raiseActive()
    end
end

function NorskLaaveWorkshopInteraction:onUpdate(dt)
    if not self.isClient then return end
    local spec = self[NorskLaaveWorkshopInteraction.SPEC_TABLE_NAME]
    if spec.deleted then return end
    -- Continue checking while a client has this placeable loaded. This also
    -- handles loading a save while the player is already inside the trigger.
    self:raiseActive()
    spec.elapsedMs = spec.elapsedMs + dt
    if spec.elapsedMs < NorskLaaveWorkshopInteraction.POLL_INTERVAL_MS then return end
    spec.elapsedMs = 0

    local mission = g_currentMission
    local system = mission ~= nil and mission.activatableObjectsSystem or nil
    local player = g_localPlayer
    local sellingPoint = self.spec_workshop ~= nil and self.spec_workshop.sellingPoint or nil
    local activatable = sellingPoint ~= nil and sellingPoint.activatable or nil
    local playerNode = player ~= nil and player.rootNode or nil
    local pointNode = sellingPoint ~= nil and sellingPoint.playerTrigger or nil
    if system == nil or playerNode == nil or playerNode == 0 or pointNode == nil or pointNode == 0
        or not entityExists(playerNode) or not entityExists(pointNode) or activatable == nil then
        removeRegistered(spec)
        return
    end
    if mission.missionInfo ~= nil and FSCareerMissionInfo ~= nil
        and not mission.missionInfo:isa(FSCareerMissionInfo) then
        removeRegistered(spec)
        return
    end
    if spec.registeredActivatable ~= nil and spec.registeredActivatable ~= activatable then
        removeRegistered(spec)
    end

    local px, py, pz = getWorldTranslation(playerNode)
    local tx, ty, tz = getWorldTranslation(pointNode)
    local dx, dz = px - tx, pz - tz
    local near = dx * dx + dz * dz <= NorskLaaveWorkshopInteraction.RADIUS ^ 2
        and math.abs(py - ty) <= NorskLaaveWorkshopInteraction.HEIGHT_TOLERANCE
    if near and activatable:getIsActivatable() then
        -- addActivatable is idempotent. Reassert it each poll because a stock
        -- trigger onLeave callback may remove the same action between polls.
        system:addActivatable(activatable)
        spec.registeredActivatable = activatable
    else
        removeRegistered(spec)
    end
end

function NorskLaaveWorkshopInteraction:onDelete()
    local spec = self[NorskLaaveWorkshopInteraction.SPEC_TABLE_NAME]
    if spec ~= nil then
        spec.deleted = true
        removeRegistered(spec)
    end
end
