#!/usr/bin/env python3
"""Generate FS25 light XML from the prefab's actual imported scene paths.

Requires Python 3.9 or newer, no extra packages. Input files are never overwritten.
"""
import argparse
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

PREFIX = 'kkmPrefab'
ET.register_namespace('xsi', 'http://www.w3.org/2001/XMLSchema-instance')

def generate(i3d_path, vehicle_path=None):
    model = ET.parse(i3d_path)
    scene = model.getroot().find('Scene')
    if scene is None:
        raise ValueError('I3D-filen mangler Scene.')
    parents = {child: parent for parent in scene.iter() for child in parent}
    def index_path(node):
        parent = parents[node]
        if parent is scene:
            return str(list(scene).index(node)) + '>'
        return index_path(parent) + ('' if parents.get(parent) is scene else '|') + str(list(parent).index(node))
    def resolve(path):
        if not re.fullmatch(r'\d+>(?:\d+(?:\|\d+)*)?', path):
            raise ValueError('Ugyldig i3dMapping-sti: ' + str(path))
        first, tail = path.split('>')
        node = scene[int(first)]
        for number in tail.split('|'):
            if number:
                node = node[int(number)]
        return node
    groups = {}
    for group_name in ['Frame_Lights_Logos', 'Ramp_Lights_Logos']:
        matches = [n for n in scene.iter('TransformGroup') if n.get('name') == group_name]
        if len(matches) != 1:
            raise ValueError(f'Fant {len(matches)} grupper med navnet {group_name}; det må være nøyaktig én. Importer samlet prefab ELLER begge delene, ikke begge alternativene.')
        groups[group_name] = matches[0]
    def unique_group(parent, name):
        found = [n for n in parent.iter('TransformGroup') if n.get('name') == name]
        if len(found) != 1:
            raise ValueError(f'Forventet én gruppe {name}, fant {len(found)}.')
        return found[0]
    if vehicle_path:
        output = ET.parse(vehicle_path)
        root = output.getroot()
        if root.tag != 'vehicle':
            raise ValueError('Kjøretøy-XML må ha vehicle som rot.')
    else:
        root = ET.Element('vehicle')
        root.append(ET.Comment('Lysutdrag: flett lights og i3dMappings inn i kjøretøyets eksisterende XML.'))
        output = ET.ElementTree(root)
    lights = root.find('lights')
    if lights is None:
        lights = ET.SubElement(root, 'lights')
    defaults = lights.find('defaultLights')
    if defaults is None:
        defaults = ET.SubElement(lights, 'defaultLights')
    beacons = lights.find('beaconLights')
    if beacons is None:
        beacons = ET.SubElement(lights, 'beaconLights')
    mappings = root.find('i3dMappings')
    if mappings is None:
        mappings = ET.SubElement(root, 'i3dMappings')
    # Re-running against an already wired vehicle replaces this prefab's
    # entries and preserves the rest of the vehicle's light definitions.
    for entry in list(mappings):
        if entry.get('id', '').startswith(PREFIX):
            mappings.remove(entry)
    for entry in list(defaults):
        if entry.get('node', '').startswith(PREFIX):
            defaults.remove(entry)
    for entry in list(beacons):
        if any(n.get('node', '').startswith(PREFIX) for n in entry.findall('staticLight')):
            beacons.remove(entry)
    for entry in mappings.findall('i3dMapping'):
        try:
            resolve(entry.get('node'))
        except (ValueError, IndexError, TypeError) as error:
            raise ValueError(f'Eksisterende mapping {entry.get("id")} peker feil i valgt I3D. Rett eller fjern gammel mapping før du fletter inn prefaben.') from error
    for area, count, group_name, lens_name in [
        ('Side',100,'Frame_Lights_Logos','Static_hvit'),
        ('Ramp',64,'Ramp_Lights_Logos','Static_red'),
    ]:
        for number in range(1, count + 1):
            group = unique_group(groups[group_name], f'Marker_{area}_{number:03d}')
            lens = next((n for n in group.iter('Shape') if n.get('name') == lens_name), None)
            if lens is None or lens.get('visibility', 'true') == 'false':
                raise ValueError(f'Mangler synlig {lens_name} i {group.get("name")}.')
            identifier = f'{PREFIX}Marker{area}{number:03d}'
            ET.SubElement(defaults,'defaultLight',node=identifier,lightTypes='0',intensity='100',uvSlotIndex='1')
            ET.SubElement(mappings,'i3dMapping',id=identifier,node=index_path(lens))
    for number in range(1, 11):
        group = unique_group(groups['Ramp_Lights_Logos'], f'NYX_{number:02d}')
        lens = next((n for n in group.iter('Shape') if n.get('name') == 'blitz_static'), None)
        beam = lens.find('Light[@name="strobe"]') if lens is not None else None
        if beam is None:
            raise ValueError(f'Mangler NYX lysflate eller lyskilde i {group.get("name")}.')
        static_id = f'{PREFIX}NyxStatic{number:02d}'
        beam_id = f'{PREFIX}NyxBeam{number:02d}'
        phase = '0' if number <= 5 else '12.5663706'
        beacon = ET.SubElement(beacons,'beaconLight',realLight=beam_id)
        ET.SubElement(beacon,'staticLight',node=static_id,intensity='400',multiBlink='true',multiBlinkParameters=f'2 2 65 {phase}')
        ET.SubElement(mappings,'i3dMapping',id=static_id,node=index_path(lens))
        ET.SubElement(mappings,'i3dMapping',id=beam_id,node=index_path(beam))
    ids = [entry.get('id') for entry in mappings.findall('i3dMapping')]
    if len(ids) != len(set(ids)):
        raise ValueError('Kjøretøyet har dupliserte i3dMapping-id-er.')
    for entry in mappings.findall('i3dMapping'):
        resolve(entry.get('node'))
    ET.indent(output, space='    ')
    return output

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--i3d',required=True,type=Path,help='Kjøretøyets lagrede I3D etter at prefaben er importert.')
    parser.add_argument('--vehicle',type=Path,help='Valgfri eksisterende kjøretøy-XML som skal få lysene flettet inn.')
    parser.add_argument('--output',required=True,type=Path,help='Ny XML-fil; originalfilene overskrives ikke.')
    args=parser.parse_args()
    if args.output.resolve() in {p.resolve() for p in [args.i3d,args.vehicle] if p is not None}:
        parser.error('--output må være en ny fil, ikke en av originalfilene.')
    try:
        output=generate(args.i3d,args.vehicle)
        args.output.parent.mkdir(parents=True,exist_ok=True)
        output.write(args.output,encoding='utf-8',xml_declaration=True)
    except (OSError,ET.ParseError,ValueError,IndexError) as error:
        print('Feil:',error,file=sys.stderr)
        return 1
    print('Skrevet:',args.output)
    print('164 markeringslys, 10 NYX-blitzere med bakkelys og 184 mappinger er lagt til.')
    return 0

if __name__=='__main__':
    raise SystemExit(main())
