VOLVO L90 — ORANGE DRL AND SCANIA-STYLE OPTIBEAM
Version 1.0.0.4

Built from the NEW user-uploaded three-part RAR, retaining all original model
and binary geometry, textures, wheel/bucket assets and vehicle settings.

All 15 fitted FOR9T guides and both OZZ position guides use orange engine-on
DRL. The FOR9Ts use the original orange UV/texture atlas, at intensity 20.
OZZ position DRLs use intensity 40. Their white road/work functions remain.
The Optibeam has separate orange engine-on cruise glow at intensity 8 and
the same native alternating double flash as the Scanias, intensity 12, with
six 100 m projected beacon lights. Flashing orange projectors are off between
pulses and do not run with the steady DRL/cruise lights.

Front/forward-side FOR9T work lamps follow front work lights (F-key stage 3);
rear/back-side FOR9Ts follow rear work lights (stage 2). OZZ near/high beams,
indicators and strobes use their own fitted meshes and projected lights.
The existing rear, brake, reverse and other standard vehicle controls remain.

The electric L90 inherits the same light setup. The included bucket is intact.
No additional lighting script or Interactive Control mod is required.

Ten imported OZZ/bar texture references pointed to absent OneDrive files.
Missing normals/dirt/gloss/glass now use standard neutral game assets; orange
emission uses a bundled uniform amber map. Original surface detail may differ.

Exit FS25 fully, replace FS25_volvoL90.zip, keep that exact filename, and
restart. Install this complete single ZIP, with modDesc.xml at its root.
Model references, controls, amber emission, original geometry identity and
ZIP CRC checked. Not tested in the FS25 game runtime.
