John Deere 6030 Lights — FS25 compatibility test, v0.4

Fixes the v0.1 loading-script failure and the six float4-to-float3 assignments
reported by the game shader compiler. The corrected shader is included in this
mod; the installed game files are not edited.

NOT VERIFIED IN GIANTS EDITOR OR FARMING SIMULATOR 25.
Put the ZIP, without extracting it, in Documents/My Games/FarmingSimulator2025/mods.
Enable the mod in a test save and buy the tractor. Test headlights, front/rear work
lights, turn indicators, brake lights and HOME-key beacons/light-bar strobes.
Try the light/cab configurations in the shop. Test driving, steering and attachments.
If it fails or lights/materials look wrong, send FarmingSimulator2025/log.txt.

Uses a repaired copy of FS25's FS22 compatibility shader to preserve the original UV material
slots and static light controls. Original binary geometry and existing node indices are retained. See LIGHTING_CHANGES.txt for the v0.4 lighting edits.
Unavailable old normal/mask textures use FS25 neutral shared resources. Missing
decorative diffuse atlases are transparent: some decals/detail are absent.
Tyres use FS25 models with matching brand/product and size where available;
two missing Trelleborg TM100 sizes use TM600. Tyre fit still needs game validation.
Legacy dashboard shaders use compatibility static-light materials; dashboard
illumination needs checking. Top arms use FS25 XML assets. Diesel tanks have an
exact fill root at the chassis origin; the refill position needs checking.
TirePressure has been adapted to XMLFile and FS25 Wheel.physics; pressure changes
friction, while the obsolete suspension/deformation adjustment is removed.
Legacy nil/default and vector parsers have been replaced with local helpers;
cleanup tolerates a vehicle that failed to load. The sound set uses FS25 John Deere
6M sounds instead of the missing legacy hydraulic/attachment/horn templates.
InteractiveControl definitions are retained, but require a compatible FS25 IC mod.
Collision conversion, suspension, sound templates, attachments, fuel refilling,
materials, dashboards, physics and multiplayer require engine validation.

Original credits: Udruzenje Nezavisnih Modera, ANO Modding; TirePressure: Wopster.
Original source is retained separately and unchanged.
