John Deere 6030 Lights — FS25 compatibility test, v0.1

NOT VERIFIED IN GIANTS EDITOR OR FARMING SIMULATOR 25.
Put the ZIP, without extracting it, in Documents/My Games/FarmingSimulator2025/mods.
Enable the mod in a test save and buy the tractor. Test headlights, front/rear work
lights, turn indicators, brake lights and HOME-key beacons/light-bar strobes.
Try the light/cab configurations in the shop. Test driving, steering and attachments.
If it fails or lights/materials look wrong, send FarmingSimulator2025/log.txt.

Uses FS25's bundled FS22 compatibility shader to preserve the original UV material
slots and static light controls. No geometry or scene node ordering was changed.
Unavailable old normal/mask textures use FS25 neutral shared resources. Missing
decorative diffuse atlases are transparent: some decals/detail are absent.
Tyres use FS25 models with matching brand/product and size where available;
two missing Trelleborg TM100 sizes use TM600. Tyre fit still needs game validation.
Legacy dashboard shaders use compatibility static-light materials; dashboard
illumination needs checking. Top arms use FS25 XML assets. Diesel tanks have an
exact fill root at the chassis origin; the refill position needs checking.
TirePressure has been adapted to XMLFile and FS25 Wheel.physics; pressure changes
friction, while the obsolete suspension/deformation adjustment is removed.
InteractiveControl definitions are retained, but require a compatible FS25 IC mod.
Collision conversion, suspension, sound templates, attachments, fuel refilling,
materials, dashboards, physics and multiplayer require engine validation.

Original credits: Udruzenje Nezavisnih Modera, ANO Modding; TirePressure: Wopster.
Original source is retained separately and unchanged.
