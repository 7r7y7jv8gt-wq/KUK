SCHWARZMUELLER SEMI LOWLOADER 3A — THREE-WAY VIKING MARKERS
Version 1.0.0.3

All six fitted Viking lamps now have white forward guides, amber outward
side guides and red rear guides, at intensity 20. Both near and far LODs
are controlled by the towing vehicle's normal light stage (lightTypes 0).
Switch on the truck's regular lights after attaching the trailer.

The source model had front/rear guides only. Its original ring geometry is
reused for the added side-facing amber guides. The main shape binary and
all original fixture positions are unchanged. All existing rear, brake,
reverse, indicator and beacon controls are retained.

The imported Viking textures pointed to missing OneDrive files. Bundled
solid red/white/amber emission maps restore the three colors. Missing dirt
masks use the neutral game vehicle mask, so original dirt detail differs.
The unrelated original KKMaskin logo texture was also absent; its original
model/material/reference is retained. Supply the original DDS to restore it.

Exit FS25 fully, replace FS25_semiLowloader3A.zip with this complete ZIP,
keep the filename, and restart the game. XML, node paths, light controls,
geometry directions, included textures and ZIP integrity are checked.
No live FS25 game test has been performed.
