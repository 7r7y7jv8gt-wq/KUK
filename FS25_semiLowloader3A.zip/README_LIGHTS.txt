SCHWARZMUELLER SEMI LOWLOADER 3A — VIKING LIGHTS AND HORIZONTAL LOGOS
Version 1.0.0.5

Built from the owner's NEW upload with their newly fitted rear mudflap logo.
The rear horizontal K&K Maskin logo now uses the exact original horizontal
DDS already bundled in the mod, rather than the missing OneDrive path.
Both side logos use the same owner-supplied DDS. Lettering, artwork, alpha
and mipmaps are preserved without editing the texture.

The owner's latest logo placements and scales are retained, including the
enlarged side logos and rear decal. The old rear wordmark remains hidden
as set in this upload. The new model and its matching shape binary are kept.

All six three-way Viking lamps retain white forward, amber outward and
red rear guides, intensity 20, in both LODs. They follow the towing truck's
regular lights. Existing trailer lights, controls and settings are preserved.

Exit FS25 fully, replace FS25_semiLowloader3A.zip, keep the filename, and
restart the game. Texture references, original asset identity, node paths,
logo orientation and ZIP integrity are checked. No live FS25 game test
has been performed.
