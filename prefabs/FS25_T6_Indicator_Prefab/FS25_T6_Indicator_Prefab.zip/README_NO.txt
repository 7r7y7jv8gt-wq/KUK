NEW HOLLAND T6 – BLINK- OG POSISJONSLYKT FOR FS25

Innhold
- t6IndicatorLeft.i3d: venstre lykt.
- t6IndicatorRight.i3d: høyre lykt.
- t6Indicator.i3d.shapes: felles binær geometri.
- Nødvendige lokale DDS-teksturer og prefabDesc.xml.
- vehicle_XML_examples.xml: kobling til kjøretøyets vanlige lysfunksjoner.

Originalmodell og teksturer: Arek, FS25_newHollandT6 1.0.0.0.
Se CREDITS.txt. Originale materialer, farger og kodede lyskanaler er bevart.
Prefaben bruker også native shadere og detaljteksturer fra FS25-installasjonen.

IMPORT I GIANTS EDITOR 10
1. Pakk ut hele prefab-mappen i modprosjektet ditt, for eksempel
   prefabs/T6_Indicator/. Behold .i3d-, .i3d.shapes- og teksturfilene samlet.
2. Åpne kjøretøyets .i3d og importer t6IndicatorLeft.i3d eller
   t6IndicatorRight.i3d med File > Import. Importer begge hvis du ønsker et par.
3. Legg den importerte hovedgruppen under kjøretøyets bevegelige karosseri
   eller hytte i Scenegraph. Da følger lykten kjøretøyet.
4. Plasser og roter hele T6_Indicator_Left eller T6_Indicator_Right samlet.
   Modellen er i meter med skala 1. Monteringspunktet ligger ved lyktens bakside;
   forsiden peker mot lokal +Z. Hver hovedgruppe har disse barna:
       |0  housing    hus og reflektorer
       |1  lens       glass
       |2  turnLight  reell oransje lyskilde
5. Lagre kjøretøyets .i3d. Kontroller at filbanene til prefab-teksturene fortsatt
   peker inn i modprosjektet ditt.

KOBLING I KJØRETØYETS XML
Kjøretøyet må bruke den vanlige FS25-spesialiseringen Lights.

1. Åpne vehicle_XML_examples.xml. Dokumentet inneholder utdrag som skal flettes
   inn i kjøretøyets eksisterende XML. Behold øvrige lys og i3dMappings.
2. Kopier node-linjene inn i eksisterende lights/staticLightCompounds/
   staticLightCompound. Lag denne seksjonen dersom kjøretøyet mangler den.
3. Kopier turnLightLeft og turnLightRight inn i lights/realLights/high.
4. Kopier de seks i3dMapping-linjene inn i kjøretøyets i3dMappings.
5. Erstatt VENSTRE_ROTSTI og HOYRE_ROTSTI med de faktiske indeksstiene til
   de importerte hovedgruppene i kjøretøyets Scenegraph. Behold |0, |1 og |2
   etter rotstien. Eksempel: hvis venstre hovedgruppe har indekssti
   0>0|8|2, blir husets mapping 0>0|8|2|0.

Hvis du bare monterer én lykt, bruker du bare XML-linjene for den siden.
Forsiden og lyskilden flyttes sammen når hele hovedgruppen roteres.

SLIK VIRKER LYSENE
Hus/reflektorer registreres som staticLightCompound med intensity="5" og
glassdelen med intensity="1", slik de er satt opp i originalmodellen.
De bevarte lys-ID-ene kobler glass/reflektorer til blinklys og posisjonslys.
De reelle oransje lysene registreres som turnLightLeft og turnLightRight.
FS25 styrer blinkrytme og nødblink; ingen separat Lua trengs.
De reelle lysene følger spillets grafikkvalg for lyskvalitet.

KONTROLL ETTER IMPORT
Prøv venstre blink, høyre blink, nødblink og vanlige posisjonslys.
Kontroller at bare riktig side blinker, og at den hvite delen følger de
vanlige lysene. Prøv også i mørke for å kontrollere lysretningen.
Se etter manglende filer, shaderfeil eller ugyldige nodebaner i
Dokumenter/My Games/FarmingSimulator2025/log.txt.

Prefaben er laget for import i et kjøretøyprosjekt. Modellen og teksturene
registreres ikke som et eget kjøpbart kjøretøy ved å legge ZIP-en i mods.
Filstruktur og geometri kan kontrolleres her. Endelig funksjon etter montering
må kontrolleres i GIANTS Editor 10 og FS25.
