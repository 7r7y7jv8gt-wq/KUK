SCANIA S TRIDEM — FOUR NAME LAYOUTS

Shop: Name layout
  1. J. Kristensen driver / M. Kolbræk passenger (default)
  2. M. Kolbræk driver / J. Kristensen passenger
  3. J. Kristensen on the driver door only; passenger door blank
  4. M. Kolbræk on the driver door only; passenger door blank

Original lettering, Norwegian flags, transparent DDS textures and inline meshes
come from the supplied FS25_Norske_Navnelogoer.zip and are copied unchanged.
Names occupy the same door positions as on the other Scania. Driver is vehicle
left. Existing curtain choices (red default), all lights and vehicle settings
are preserved. No Interactive Control add-on is required for name selection.

Replace FS25_ScaniaS_Tridem.zip and restart FS25. Names are selected in the
vehicle shop/customization menu. Not tested in FS25/GIANTS Editor.
