SCANIA S TRIDEM — NAVNEVALG 1.3.0.1

Samme Tridem-lastebil og ett «Name layout»-valg i butikken.
Versjon i modoversikten: 1.3.0.1

Velg «Name layout» ved takvalget i kjøp/tilpasning:
  1. J. Kristensen sjåfør / M. Kolbræk passasjer (standard)
  2. M. Kolbræk sjåfør / J. Kristensen passasjer
  3. J. Kristensen – kun sjåførdør, tom passasjerdør
  4. M. Kolbræk – kun sjåførdør, tom passasjerdør

Avslutt FS25 helt. Erstatt den gamle FS25_ScaniaS_Tridem.zip i mods-mappen
med denne ZIP-en, behold nøyaktig filnavn, og start spillet igjen. Aktiver
Tridem-modden. Kontroller versjon 1.3.0.1 i modoversikten.

Navnevalget bruker nå ledig design2, tidlig i butikkmenyen. Den tidligere
design15-definisjonen er gyldig i FS25; den konkrete grunnen til at valget
manglet på brukerens maskin er ikke fastslått. Denne utgaven gir valget en
samme tittel og fire alternativer som den andre Scaniaen. Versjonsnummeret
lar deg skille filen fra eldre utgaver i modoversikten.

Original skrift, norske flagg, modeller, plassering, lys, gardiner og kjøretøy-
innstillinger er beholdt. Ingen IC-mod kreves for navnevalgene.
Fil- og konfigurasjonskontroller er utført. Ikke testet i FS25/GIANTS Editor.
