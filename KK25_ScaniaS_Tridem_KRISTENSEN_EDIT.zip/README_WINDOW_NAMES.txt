SCANIA S TRIDEM — OWNER-FITTED WINDOW NAMES
Version 1.3.0.3

There is one name dropdown in the shop: "Vindu navn".
  J. Kristensen (default)
  M. Kolbræk

These are the two names fitted in the owner's "Vindu navn" transform group.
Exactly one is visible at a time. The old imported door-name models and
their four-choice "Name layout" dropdown have been removed.

The original name DDS files, lettering, Norwegian flags, transparency and
mipmaps are retained byte for byte. The window-name geometry, placement,
native design13 configuration and stable save IDs are retained. No extra
script is needed. Existing vehicle features and other shop options remain.

Exit FS25 fully, replace KK25_ScaniaS_Tridem_KRISTENSEN_EDIT.zip, keep this
filename and restart. Open this truck in the shop/customization screen and
select "Vindu navn". Native configuration metadata, name switching, node
and texture references, asset identity and ZIP integrity are checked.
No live FS25 game test has been performed.
