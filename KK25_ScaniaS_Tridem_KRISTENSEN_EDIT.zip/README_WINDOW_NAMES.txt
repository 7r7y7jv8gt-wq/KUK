SCANIA S TRIDEM — WINDOW NAME CONFIGURATION
Version 1.3.0.2

The shop now has a separate "Vindu navn" dropdown:
  J. Kristensen (default)
  M. Kolbraek (displayed as M. Kolbræk in the shop)

Exactly one name is visible in the owner's "Vindu navn" group. The new
choice is independent of the existing four "Name layout" door choices.
Window name positions and scales are kept exactly as fitted in this upload.

Both window meshes use the original supplied DDS files already included
under decor/names/textures. Their lettering and Norwegian flags are kept
byte for byte; missing OneDrive references are replaced with local paths.

The new dropdown uses native design13 configuration, needs no extra script
and has stable save IDs for each name. Existing configurations, lights,
vehicle settings, assets and the owner's new shape binary are retained.

Exit FS25 fully, replace KK25_ScaniaS_Tridem_KRISTENSEN_EDIT.zip with this
complete ZIP, keep that exact filename and restart. Open the shop/customize
screen for this truck and select "Vindu navn". Native configuration parsing,
visibility switching, original asset identity, node/texture references and
ZIP integrity are checked. No live FS25 game test has been performed.
