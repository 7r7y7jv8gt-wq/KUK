BERGAAS SCANIA TIPPER PACK — OZZ, OPTIBEAM AND WINDOW NAMES
Version 1.0.0.1

All ten fitted OZZ/Briod lamps have white engine-on DRL at intensity 20.
Their main light follows the truck's high-beam circuit (light type 3), with
emission intensity 50, down from the source's 100. Their projected beams
have 100 m range, reduced brightness and a wide fan. Low/high graphics
profiles use distinct projected-light nodes. The misplaced old auxiliary
projectors are disabled. The standard road lights retain their controls.

The fitted Optibeam uses alternating double flashes, intensity 12 and
100 m projected beacon lights, with separate orange engine-on cruise
lights at intensity 8, like the owner's other Scanias. The bar is linked
to the truck so it follows it. All six projected beacons start off.
Native-controlled external flash meshes preserve the original geometry
and emission atlas while correcting the source's light UV channel offset.
No custom runtime lighting script is required.

The shop has one "Vindu navn" choice: J. Kristensen (default) or M. Kolbræk.
Original name lettering, Norwegian flags, alpha and mipmaps are preserved
byte for byte. Both are fitted to this cab's driver-side glass and follow
the cab. Exactly one name is shown, and no old door-name layouts are added.

The five absent OZZ/Optibeam image references are restored with existing
matching assets from the owner's other mods. All original source textures
and shape binaries, both included trailers and vehicle/tipper settings
are retained. Existing TerraFarm/specialization integrations are retained.

Exit FS25 fully, replace FS25_BergaasDesign_Scania_Tipper_Pack.zip with this
complete ZIP, keep the filename, and restart. The package is checked for
light controls, blink timing/UVs, name visibility, original asset identity,
node and texture references and ZIP integrity. No live FS25 game test has
been performed.
