-- Optional source integrations are attached only when their provider is loaded.
-- The native type manager still validates and registers every added specialization.
local modName = g_currentModName
local typeNames = {
    truck = modName .. ".ScaniaTipper",
    trailer = modName .. ".customTrailer"
}

local function addIfAvailable(manager, typeName, specializationName)
    local vehicleType = manager.types[typeName]
    if vehicleType ~= nil
        and vehicleType.specializationsByName[specializationName] == nil
        and manager.specializationManager:getSpecializationObjectByName(specializationName) ~= nil then
        manager:addSpecialization(typeName, specializationName)
    end
end

local function registerOptionalSpecializations(manager)
    if manager ~= g_vehicleTypeManager then
        return
    end

    -- Keep the source's lightExtension lookup: global first, then this mod.
    local lightExtension = "lightExtension"
    if manager.specializationManager:getSpecializationObjectByName(lightExtension) == nil then
        lightExtension = modName .. ".lightExtension"
    end
    addIfAvailable(manager, typeNames.truck, lightExtension)
    addIfAvailable(manager, typeNames.truck, "FS25_0_TerraFarm.machine")
    addIfAvailable(manager, typeNames.trailer, "FS25_0_TerraFarm.machine")
end

TypeManager.validateTypes = Utils.prependedFunction(TypeManager.validateTypes, registerOptionalSpecializations)
