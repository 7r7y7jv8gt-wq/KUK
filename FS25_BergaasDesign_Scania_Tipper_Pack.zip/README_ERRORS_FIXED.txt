Scania — feilrettet pakke
Versjon: 1.0.0.4

Denne pakken retter Scania-feil og relevante advarsler fra loggen som ble
sendt 30.10.2026, samt konkrete feil funnet ved kontroll av de andre
variantene. Originale navn/flagg, valg, meshdata, plasseringer og
lysintensiteter er bevart. Gardinlasting, lysprofiler og modspesifikke
Lua-/XML-feil er rettet der de gjelder denne pakken.

Avslutt FS25, erstatt den tilsvarende mod-ZIP-en og start spillet på nytt.
Behold filnavnet. Versjonen erstatter tidligere pakker med samme navn.

Det er gjort kontroller av filer, XML, noder, lys-/konfigurasjonskode og
ZIP-integritet. Ingen ny test inne i FS25 er utført. Loggen inneholder
også feil fra andre modder; disse er ikke en del av Scania-pakkene.

Bergaas-modellens opprinnelige store mesh har fortsatt en størrelses-
advarsel for konsoll. Originalgeometrien er bevart. Dette er en egen
plattformadvarsel, og ikke en manglende fil eller en Lua-feil på PC.
