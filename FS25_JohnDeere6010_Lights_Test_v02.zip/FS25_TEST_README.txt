John Deere 6010 Series — FS25 lights test v0.2
This is a test candidate, not an in-game verified conversion.
Original authorship: DB Modding; original edit assets remain attributed as supplied.
Both four-cylinder and edited six-cylinder vehicles are included.
Original light states, emissive light entries, node indices, beacon attachments,
blinkOffset values, meshes and visible vehicle wheel configurations are retained.
The six-cylinder cabin point light is moved from an invalid emissive-surface
registration to realLights in both low and high graphics profiles.
FS25 compatibility shaders are bundled; the custom TZG cosine flash is ported.
Two malformed attributes and ten invalid XML separator comments are repaired.
Dormant BKT donor PTG/weight variants unused by these vehicles are omitted.
Some legacy game texture references use documented mappings from the retained
6030 conversion; old frontloader texture mappings include generic normal/vmask
fallbacks. Remaining external game assets and sound templates need validation
against your installed FS25. FS25/Editor are unavailable in this cloud machine.

Install the ZIP without extracting it in your FS25 mods folder. Disable earlier
6010 copies. Enable this candidate in a test save and try buying both tractors.
Test all shop light configurations, normal lights, high beams, front/rear work
lights, turn signals, hazards, brakes, number plate lights, dashboard lighting,
interior/Poppy lights and the six-cylinder 24 attached flash beacons.
Test warnings on/off, each wheel choice, driving and front-loader attachments.
Send a fresh Documents/My Games/FarmingSimulator2025/log.txt after the test.
The cloud XML/node/resource checks do not prove shader compilation or game loading.
