SCANIA S — THREE-WAY VIKING MARKERS
Version 1.0.2.2

Built from the user's latest three-part RAR. All six fitted GeoViking lamps
on the S 6x4 have white forward guides, amber outward side guides and red
rear guides at intensity 20. Both LODs follow the regular running-light
stage (lightTypes 0), matching the Semi Lowloader 3A.

The source lights parent reverses the local front/rear directions. Colors
are assigned by the vehicle's actual forward direction: local rearGuides
are white and local frontGuides are red. Fixture positions are preserved.
Small amber guides reuse the original ring geometry against each outer
rubber housing, exactly as in the trailer patch.

The imported Viking textures referenced absent OneDrive files. Bundled
white/red/amber emission maps restore the colors. Missing dirt maps use
the native neutral vehicle mask; original dirt detail may differ.

All original shape binaries, other assets, chassis variants, lights,
name/curtain configurations and grille-sign IC code are retained from this
upload. Briod high-beam intensity remains 200 and its DRL remains 40.

Exit FS25 fully, replace FS25_ScaniaS.zip with this complete ZIP, keep that
filename and restart. XML, node paths, source asset identity, directions,
both LODs, emission maps and ZIP integrity are checked. No live FS25 game
test has been performed.
