SCANIA S 6x4 — NAME TEXTURES AND FRONT SIGN IC

This version includes all six previously missing artwork textures.
The artwork is newly authored replacement lettering; the originals were not
included in the uploaded vehicle. Name decals are white with a dark outline
and a transparent background. Load signs are black on yellow.

Shop: Name layout
  1. J. Kristensen left / M. Kolbræk right (default)
  2. M. Kolbræk left / J. Kristensen right

Front transport sign: enable FS25_interactiveControl for interaction.
  One click point opens/closes the sign.
  The other cycles TUNG LAST -> LANG LAST -> BRED LAST while it is open.

Existing fitted lighting is preserved: Briod high beam 200, white DRL 40.
Name positions, all binary geometry, driving data and other variants are
unchanged. DDS textures use BC3/DXT5 alpha and full mip chains.

Asset and code checks passed. No FS25/GIANTS Editor visual test was available;
the appearance, UV fit and folding motion still need an in-game check.
