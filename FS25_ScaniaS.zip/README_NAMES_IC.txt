SCANIA S 6x4 — ORIGINAL NAME LOGOS AND CORRECT FRONT SIGN
Version 1.0.2.1

The GV604 now shows its actual printed front, with readable, unmirrored text.
The grey diffuser is hidden while the printed panel is displayed. The original
card meshes sit inside the frame at their original depths. The small top cap
opens about its actual top/rear edge; it no longer folds around the box centre.

Enable FS25_interactiveControl and activate outdoor IC while standing in front
of the truck. The points are on the FRONT lower corners of the sign:
  LEFT when looking at the truck: open/close the cap and show/hide the sign.
  RIGHT when looking at the truck: TUNG LAST -> LANG LAST -> BRED LAST.
The right point is enabled while the sign is open. The selected panel and
open/closed state are saved and synchronized through native IC.
The blank grey face is intentional when closed; open it using the left point.

Name layout keeps all four choices and the original lettering/Norwegian flags:
  J. Kristensen driver / M. Kolbræk passenger (default)
  M. Kolbræk driver / J. Kristensen passenger
  J. Kristensen driver only; passenger blank
  M. Kolbræk driver only; passenger blank

Briod high beam remains 200 and white DRL 40. Other fitted lights, beam ranges,
vehicle settings, original binary geometry and the 4x2/8x4 models are retained.

Exit FS25 fully, replace FS25_ScaniaS.zip, keep its filename and restart. Check
version 1.0.2.1. Actual decoded geometry, UV direction, panel clearance, hinge,
IC control positions, native animation code and ZIP CRC have been checked.
Blender previews are diagnostic renders; not tested in the FS25 game runtime.
