CURRENT VERSION: NAME CONFIGURATIONS + GV604 IC CODE

The original six DDS image files were absent from the owner's archive.
Names and load-sign artwork will not render correctly until they are supplied.
This ZIP includes the full truck and the new code; it is not artwork-complete.

Name layout in the shop:
1. J. Kristensen left / M. Kolbraek right.
2. M. Kolbraek left / J. Kristensen right.

Enable FS25_interactiveControl for the front-sign interactions.
The left click point opens/closes the sign. The right cycles heavy, long and
wide-load panels while open. Mode and fold state use native IC save handling.

Missing files must be placed at these paths inside the mod:
textures/names/J_KRISTENSEN_diffuse.dds
textures/names/M_KOLBRAEK_diffuse.dds
textures/gv604/TUNG_LAST.dds
textures/gv604/LANG_LAST.dds
textures/gv604/BRED_LAST.dds
textures/gv604/GVFlexiAdvertisment.dds

Original vehicle geometry and existing lights are preserved.
Code and references were checked. Not tested in FS25/GIANTS Editor.
