SCANIA S 6x4 — FOUR NAME LAYOUTS AND FRONT SIGN FACING FIX

Shop: Name layout
  1. J. Kristensen driver / M. Kolbræk passenger (default)
  2. M. Kolbræk driver / J. Kristensen passenger
  3. J. Kristensen on the driver door only; passenger door blank
  4. M. Kolbræk on the driver door only; passenger door blank

Both original name/flag textures from FS25_Norske_Navnelogoer.zip are retained
byte for byte. Driver means vehicle left, at the existing driver name position.

The front GV604 cassette is turned to face forward. Previously its printed
panels faced the cab and sat behind the opaque diffuser from the front view.
The two IC points keep their prior positions on the truck.
Enable FS25_interactiveControl: left point opens/closes; right point cycles
TUNG LAST -> LANG LAST -> BRED LAST while the sign is open. Saved IC state
and multiplayer handling are unchanged. Transport-sign replacement textures
remain from the previous version.

Briod high beam intensity stays at 200 and white DRL at 40. Other lighting,
vehicle settings, original binary geometry and the other variants are retained.

All name configuration transitions, model references, sign layer orientation,
original texture identity and ZIP CRC checked. No FS25/GIANTS Editor runtime
was available; the rendered sign and fold still need an in-game check.
