SCANIA S 6x4 — ORIGINAL NAME LOGOS AND FRONT SIGN IC

Original name lettering and Norwegian flags are restored using the exact DDS
files supplied in FS25_Norske_Navnelogoer.zip. Both name textures are copied
byte for byte, at their original 2048 x 256 size, with transparency and mipmaps.
No lettering, flags, texture proportions or colours have been recreated.

Shop: Name layout
  1. J. Kristensen left / M. Kolbræk right (default)
  2. M. Kolbræk left / J. Kristensen right

Front transport sign: enable FS25_interactiveControl for interaction.
  One click point opens/closes the sign.
  The other cycles TUNG LAST -> LANG LAST -> BRED LAST while it is open.
The four replacement transport-sign textures from the previous ZIP remain.

Briod high beam intensity stays at 200 and white DRL at 40. Vehicle XML, IC
code, scene, binary geometry, name positions and other variants are unchanged.

Original texture identity and archive CRC checked. Not tested in FS25/GIANTS
Editor; the rendered appearance and folding motion need an in-game check.
