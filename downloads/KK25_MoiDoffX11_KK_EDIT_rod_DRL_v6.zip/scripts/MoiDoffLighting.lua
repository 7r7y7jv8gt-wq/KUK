MoiDoffLighting = {}

function MoiDoffLighting.prerequisitesPresent(specializations)
    return true
end

function MoiDoffLighting.initSpecialization()
    local schema = Vehicle.xmlSchema
    schema:setXMLSpecializationType("MoiDoffLighting")
    schema:register(XMLValueType.NODE_INDEX, "vehicle.moiDoffLighting.drl(?)#node", "White DRL mesh")
    schema:register(XMLValueType.NODE_INDEX, "vehicle.moiDoffLighting.beacon(?)#node", "NYX flash mesh")
    schema:register(XMLValueType.NODE_INDEX, "vehicle.moiDoffLighting.beacon(?)#realLight", "NYX light source")
    schema:register(XMLValueType.FLOAT, "vehicle.moiDoffLighting.beacon(?)#phase", "Blink phase in seconds", 0)
    schema:register(XMLValueType.NODE_INDEX, "vehicle.moiDoffLighting.workLight(?)#drlNode", "Work lamp DRL mesh")
    schema:register(XMLValueType.NODE_INDEX, "vehicle.moiDoffLighting.workLight(?)#workNode", "Work lamp illuminated reflector")
    schema:register(XMLValueType.NODE_INDEX, "vehicle.moiDoffLighting.workLight(?)#realLight", "50m work beam")
    schema:setXMLSpecializationType()
end

function MoiDoffLighting.registerEventListeners(vehicleType)
    SpecializationUtil.registerEventListener(vehicleType, "onPostLoad", MoiDoffLighting)
    SpecializationUtil.registerEventListener(vehicleType, "onUpdate", MoiDoffLighting)
    SpecializationUtil.registerEventListener(vehicleType, "onDelete", MoiDoffLighting)
end

local function setMesh(node, intensity)
    if node == nil or node == 0 then return end
    setVisibility(node, intensity > 0)
    if getHasShaderParameter(node, "lightControl") then
        setShaderParameter(node, "lightControl", intensity, 0, 0, 0, false)
    elseif getHasShaderParameter(node, "lightIds0") then
        setShaderParameter(node, "lightIds0", intensity, intensity, intensity, intensity, false)
    end
end

function MoiDoffLighting:onPostLoad(savegame)
    if not self.isClient then return end
    local state = {drl = {}, beacons = {}, workLights = {}, lastDrl = nil, lastBeacon = nil}
    self.moiDoffLightsRuntime = state
    self.xmlFile:iterate("vehicle.moiDoffLighting.drl", function(_, key)
        local node = self.xmlFile:getValue(key .. "#node", nil, self.components, self.i3dMappings)
        if node ~= nil and node ~= 0 then
            table.insert(state.drl, node)
            setMesh(node, 0)
            if not getHasShaderParameter(node, "lightControl") and not getHasShaderParameter(node, "lightIds0") then
                Logging.error("[MoiDoffLights v6] DRL mesh has no light shader: %s", getName(node))
            end
        else
            Logging.error("[MoiDoffLights v6] Missing DRL node: %s", key)
        end
    end)
    self.xmlFile:iterate("vehicle.moiDoffLighting.beacon", function(_, key)
        local node = self.xmlFile:getValue(key .. "#node", nil, self.components, self.i3dMappings)
        local real = self.xmlFile:getValue(key .. "#realLight", nil, self.components, self.i3dMappings)
        local phase = self.xmlFile:getValue(key .. "#phase", 0)
        if node ~= nil and real ~= nil and node ~= 0 and real ~= 0 then
            table.insert(state.beacons, {node = node, real = real, phase = phase})
            setMesh(node, 0)
            setVisibility(real, false)
            setLightRange(real, 12)
            if not getHasShaderParameter(node, "lightControl") and not getHasShaderParameter(node, "lightIds0") then
                Logging.error("[MoiDoffLights v6] NYX mesh has no light shader: %s", getName(node))
            end
        else
            Logging.error("[MoiDoffLights v6] Missing NYX mesh or real light: %s", key)
        end
    end)
    self.xmlFile:iterate("vehicle.moiDoffLighting.workLight", function(_, key)
        local drl = self.xmlFile:getValue(key .. "#drlNode", nil, self.components, self.i3dMappings)
        local full = self.xmlFile:getValue(key .. "#workNode", nil, self.components, self.i3dMappings)
        local real = self.xmlFile:getValue(key .. "#realLight", nil, self.components, self.i3dMappings)
        if drl ~= nil and full ~= nil and real ~= nil then
            table.insert(state.workLights, {drl = drl, full = full, real = real})
            setMesh(drl, 0)
            setMesh(full, 0)
            setVisibility(real, false)
            setLightRange(real, 50)
        else
            Logging.error("[MoiDoffLights v6] Missing work light node: %s", key)
        end
    end)
    Logging.info("[MoiDoffLights v6] Loaded %d/4 work lamps (red DRL step 1 / white 50m step 2)", #state.workLights)
    Logging.info("[MoiDoffLights v6] Loaded %d/14 DRL and %d/5 NYX light pairs", #state.drl, #state.beacons)
    self:raiseActive()
end

function MoiDoffLighting:onUpdate(dt, isActiveForInput, isActiveForInputIgnoreSelection, isSelected)
    local state = self.moiDoffLightsRuntime
    if state == nil then return end
    local root = self:getRootVehicle() or self
    local rootLights = root.spec_lights
    local motorOn = root.getIsMotorStarted ~= nil and root:getIsMotorStarted()
    local mask = rootLights ~= nil and rootLights.lightsTypesMask or 0
    local drlOn = root ~= self and (motorOn or mask ~= 0)
    local beaconsOn = root.getBeaconLightsVisibility ~= nil and root:getBeaconLightsVisibility() or false
    if not beaconsOn and rootLights ~= nil then
        beaconsOn = rootLights.beaconLightsActive == true
    end
    if state.lastDrl ~= drlOn or state.lastBeacon ~= beaconsOn then
        Logging.info("[MoiDoffLights v6] DRL=%s NYX=%s attached=%s", tostring(drlOn), tostring(beaconsOn), tostring(root ~= self))
        state.lastDrl, state.lastBeacon = drlOn, beaconsOn
    end
    for _, node in ipairs(state.drl) do setMesh(node, drlOn and 15 or 0) end
    local workDrlOn = root ~= self and mask % 2 >= 1
    local workOn = root ~= self and math.floor(mask / 4) % 2 >= 1
    for _, lamp in ipairs(state.workLights) do
        setMesh(lamp.drl, workDrlOn and 15 or 0)
        setMesh(lamp.full, workOn and 60 or 0)
        setVisibility(lamp.real, workOn)
    end
    local seconds = getShaderTimeSec()
    for _, beacon in ipairs(state.beacons) do
        local phaseTime = (seconds + beacon.phase) % 0.9
        local pulseOn = beaconsOn and phaseTime < 0.4 and phaseTime % 0.1 < 0.045
        setMesh(beacon.node, pulseOn and 2000 or 0)
        setVisibility(beacon.real, pulseOn)
        if pulseOn then setLightColor(beacon.real, 2, 1, 0) end
    end
    if drlOn or beaconsOn or workOn or workDrlOn then self:raiseActive() end
end

function MoiDoffLighting:onDelete()
    local state = self.moiDoffLightsRuntime
    if state == nil then return end
    for _, node in ipairs(state.drl) do setMesh(node, 0) end
    for _, beacon in ipairs(state.beacons) do
        setMesh(beacon.node, 0)
        setVisibility(beacon.real, false)
    end
    for _, lamp in ipairs(state.workLights) do
        setMesh(lamp.drl, 0)
        setMesh(lamp.full, 0)
        setVisibility(lamp.real, false)
    end
    self.moiDoffLightsRuntime = nil
end

Logging.info("[MoiDoffLights v6] Script file loaded")
