VolvoAddedLights = {}
function VolvoAddedLights.prerequisitesPresent(s) return true end
function VolvoAddedLights.initSpecialization()
 local s=Vehicle.xmlSchema
 s:setXMLSpecializationType('VolvoAddedLights')
 local k='vehicle.volvoAddedLights.light(?)'
 s:register(XMLValueType.NODE_INDEX,k..'#node','Controlled light node')
 s:register(XMLValueType.STRING,k..'#mode','DRL, work, flash, low, high or indicator')
 s:register(XMLValueType.INT,k..'#mask','Work light bit',4)
 s:register(XMLValueType.FLOAT,k..'#phase','Flash phase',0)
 s:register(XMLValueType.FLOAT,k..'#intensity','Mesh brightness',15)
 s:register(XMLValueType.BOOL,k..'#real','Real light source',false)
 s:setXMLSpecializationType()
end
function VolvoAddedLights.registerEventListeners(t)
 SpecializationUtil.registerEventListener(t,'onPostLoad',VolvoAddedLights)
 SpecializationUtil.registerEventListener(t,'onUpdate',VolvoAddedLights)
 SpecializationUtil.registerEventListener(t,'onDelete',VolvoAddedLights)
end
local function apply(l,on)
 if l.last==on then return end
 l.last=on
 setVisibility(l.node,on)
 if not l.real and getHasShaderParameter(l.node,'lightControl') then
  setShaderParameter(l.node,'lightControl',on and l.intensity or 0,0,0,0,false)
 end
end
function VolvoAddedLights:onPostLoad(savegame)
 if not self.isClient then return end
 self.volvoAddedRuntime={nodes={},time=0}
 self.xmlFile:iterate('vehicle.volvoAddedLights.light',function(_,k)
  local n=self.xmlFile:getValue(k..'#node',nil,self.components,self.i3dMappings)
  if n==nil or n==0 then Logging.error('[VolvoAddedLights] Missing node %s',k);return end
  local l={node=n,mode=self.xmlFile:getValue(k..'#mode','drl'),mask=self.xmlFile:getValue(k..'#mask',4),phase=self.xmlFile:getValue(k..'#phase',0),intensity=self.xmlFile:getValue(k..'#intensity',15),real=self.xmlFile:getValue(k..'#real',false)}
  table.insert(self.volvoAddedRuntime.nodes,l);apply(l,false)
 end)
 Logging.info('[VolvoAddedLights] Loaded %d controlled nodes',#self.volvoAddedRuntime.nodes)
 self:raiseActive()
end
function VolvoAddedLights:onUpdate(dt)
 local s=self.volvoAddedRuntime;if s==nil then return end
 s.time=s.time+dt/1000
 local spec=self.spec_lights or {}
 local mask=spec.lightsTypesMask or 0
 local function bit(b) return math.floor(mask/b)%2==1 end
 local drl=bit(1)
 local beacon=self.getBeaconLightsVisibility~=nil and self:getBeaconLightsVisibility() or spec.beaconLightsActive==true
 local turn=self.getTurnLightState~=nil and self:getTurnLightState() or spec.turnLightState or 0
 local blink=s.time%0.8<0.4
 for _,l in ipairs(s.nodes) do
  local on=false
  if l.mode=='drl' then on=drl
  elseif l.mode=='work' then on=bit(l.mask)
  elseif l.mode=='low' then on=drl and not bit(8)
  elseif l.mode=='high' then on=bit(8)
  elseif l.mode=='left' then on=(turn==1 or turn==3) and blink
  elseif l.mode=='right' then on=(turn==2 or turn==3) and blink
  elseif l.mode=='flash' then local t=(s.time+l.phase)%0.9;on=beacon and t<0.4 and t%0.1<0.045 end
  apply(l,on)
 end
 if mask~=0 or beacon or turn~=0 then self:raiseActive() end
end
function VolvoAddedLights:onDelete()
 if self.volvoAddedRuntime~=nil then for _,l in ipairs(self.volvoAddedRuntime.nodes) do apply(l,false) end end
 self.volvoAddedRuntime=nil
end
