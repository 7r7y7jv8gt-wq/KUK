Fendt 500 Vario Gen3 – sharper steering

This REPLACES the previous wider-turn XML. Back up your mod and exit the game.
Extract this package and replace vario500.xml in the ORIGINAL tractor mod.
Keep all other mod files and restart the game.

Based on the originally uploaded XML, not the reduced-angle patch.
Maximum steering angle: 38 -> 57.381943 degrees.
Maximum steering angle: 26 -> 44.288436 degrees.

The angle uses atan(2*tan(original angle)), targeting approximately half the ORIGINAL
turning radius in a simple bicycle model. In-game Ackermann geometry, tire width,
fender/loader clearance, terrain and traction affect the actual result.
Steering speed, physics and all other XML settings are unchanged.
XML and calculations checked; not tested in FS25. Wider wheel setups may clip at full lock.
