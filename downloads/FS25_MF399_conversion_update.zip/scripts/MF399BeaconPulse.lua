MF399BeaconPulse = {}
function MF399BeaconPulse.prerequisitesPresent(s) return true end
function MF399BeaconPulse.initSpecialization()
 local s=Vehicle.xmlSchema
 s:setXMLSpecializationType('MF399BeaconPulse')
 local k='vehicle.lights.legacyFlashes.flash(?)'
 s:register(XMLValueType.NODE_INDEX,k..'#node','Legacy embedded flash node')
 s:register(XMLValueType.FLOAT,k..'#phase','Flash phase',0)
 s:register(XMLValueType.FLOAT,k..'#intensity','Flash mesh intensity',300)
 s:register(XMLValueType.BOOL,k..'#real','Real light source',false)
 s:setXMLSpecializationType()
end
function MF399BeaconPulse.registerEventListeners(t)
 SpecializationUtil.registerEventListener(t,'onPostLoad',MF399BeaconPulse)
 SpecializationUtil.registerEventListener(t,'onUpdate',MF399BeaconPulse)
 SpecializationUtil.registerEventListener(t,'onDelete',MF399BeaconPulse)
end
local function apply(light,on)
 light.last=on
 setVisibility(light.node,on)
 if not light.real and getHasShaderParameter(light.node,'lightControl') then
  setShaderParameter(light.node,'lightControl',on and light.intensity or 0,0,0,0,false)
 end
end
function MF399BeaconPulse:onPostLoad(savegame)
 if not self.isClient then return end
 local s={lights={}}
 self.mf399BeaconRuntime=s
 self.xmlFile:iterate('vehicle.lights.legacyFlashes.flash',function(_,k)
  local n=self.xmlFile:getValue(k..'#node',nil,self.components,self.i3dMappings)
  if n==nil or n==0 then Logging.error('[MF399BeaconPulse] Missing node %s',k);return end
  local l={node=n,phase=self.xmlFile:getValue(k..'#phase',0),intensity=self.xmlFile:getValue(k..'#intensity',300),real=self.xmlFile:getValue(k..'#real',false)}
  table.insert(s.lights,l);apply(l,false)
 end)
 if #s.lights>0 then Logging.info('[MF399BeaconPulse] Loaded %d embedded flash nodes',#s.lights) end
end
function MF399BeaconPulse:onUpdate(dt)
 local s=self.mf399BeaconRuntime
 if s==nil or #s.lights==0 then return end
 local active=self.getBeaconLightsVisibility~=nil and self:getBeaconLightsVisibility() or (self.spec_lights~=nil and self.spec_lights.beaconLightsActive==true)
 local now=getShaderTimeSec()
 for _,l in ipairs(s.lights) do
  local t=(now+l.phase)%0.9
  apply(l,active and t<0.4 and t%0.1<0.045)
 end
 if active then self:raiseActive() end
end
function MF399BeaconPulse:onDelete()
 local s=self.mf399BeaconRuntime
 if s~=nil then for _,l in ipairs(s.lights) do apply(l,false) end end
 self.mf399BeaconRuntime=nil
end
