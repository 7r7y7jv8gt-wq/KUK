MF300CabControls = {}
function MF300CabControls.prerequisitesPresent(s) return SpecializationUtil.hasSpecialization(AnimatedVehicle,s) end
function MF300CabControls.initSpecialization()
 local s=Vehicle.xmlSchema;s:setXMLSpecializationType('MF300CabControls')
 s:register(XMLValueType.STRING,'vehicle.mf300CabControls.panel(?)#animationName','Cab animation')
 s:register(XMLValueType.STRING,'vehicle.mf300CabControls.panel(?)#label','Cab panel label')
 s:setXMLSpecializationType()
end
function MF300CabControls.registerEventListeners(t)
 for _,e in ipairs({'onPostLoad','onRegisterActionEvents'}) do SpecializationUtil.registerEventListener(t,e,MF300CabControls) end
end
function MF300CabControls:onPostLoad(savegame)
 self.mf300CabRuntime={panels={},selected=1,actionEvents={}}
 self.xmlFile:iterate('vehicle.mf300CabControls.panel',function(_,k)
  local name=self.xmlFile:getValue(k..'#animationName')
  if name~=nil and self.spec_animatedVehicle.animations[name]~=nil then
   table.insert(self.mf300CabRuntime.panels,{name=name,label=self.xmlFile:getValue(k..'#label',name)})
  end
 end)
end
local function refresh(self)
 local s=self.mf300CabRuntime;if s==nil or s.panels[s.selected]==nil then return end
 if s.toggleId~=nil then g_inputBinding:setActionEventText(s.toggleId,'Åpne/lukk: '..s.panels[s.selected].label) end
end
function MF300CabControls:onRegisterActionEvents(isActiveForInput,isActiveForInputIgnoreSelection)
 if not self.isClient then return end
 local s=self.mf300CabRuntime;if s==nil then return end
 self:clearActionEventsTable(s.actionEvents);s.toggleId=nil
 if isActiveForInputIgnoreSelection and #s.panels>0 then
  local ok,id=self:addActionEvent(s.actionEvents,InputAction.MF300_PANEL_NEXT,self,MF300CabControls.nextPanel,false,true,false,true,nil)
  if ok then g_inputBinding:setActionEventText(id,'Velg dør/vindu') end
  ok,id=self:addActionEvent(s.actionEvents,InputAction.MF300_PANEL_TOGGLE,self,MF300CabControls.togglePanel,false,true,false,true,nil)
  if ok then s.toggleId=id;refresh(self) end
 end
end
function MF300CabControls.nextPanel(self)
 local s=self.mf300CabRuntime;if s==nil or #s.panels==0 then return end
 s.selected=s.selected%#s.panels+1;refresh(self)
end
function MF300CabControls.togglePanel(self)
 local s=self.mf300CabRuntime;if s==nil then return end
 local panel=s.panels[s.selected];if panel==nil then return end
 local tm=self:getAnimationTime(panel.name)
 self:playAnimation(panel.name,tm>=.5 and -1 or 1,tm,false)
end
