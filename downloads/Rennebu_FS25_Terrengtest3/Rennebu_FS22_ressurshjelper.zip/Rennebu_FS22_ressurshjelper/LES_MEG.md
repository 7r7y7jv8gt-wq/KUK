# Rennebu: hent de manglende FS22-ressursene

Dette er en liten lokal samler for filene som mangler i den siste Rennebu-testloggen.
Den er **ikke et ferdig konvertert FS25-kart**. FS22 må være installert først; spillet
trenger ikke å kjøre. Du trenger ikke Python eller ekstra pakkeprogrammer.

1. Installer Farming Simulator 22 fra biblioteket ditt.
2. Pakk ut hele denne hjelpepakken til en vanlig mappe på PC-en.
3. Dobbeltklikk **START_HER.cmd**. Hvis FS22 ikke finnes i en vanlig
   installasjonsmappe, velg FS22-mappen i vinduet som åpnes. Velg FS22, ikke FS25.
4. Når den er ferdig, åpnes en ny mappe under **Nedlastinger**.
5. Hvis du ser `.part001`, `.part002` osv., last opp **alle delene** sammen med
   **export_report.json** i chatten. Hvis det ikke finnes del-filer, last opp
   **Rennebu_FS22_ressurser.zip** og **export_report.json**.

Hver del er maksimalt 31 MiB. Den store vanlige ZIP-filen beholdes også på PC-en.
Delene er fortløpende biter av denne ZIP-filen; de skal ikke pakkes ut hver for seg.
Kartarbeidet kan fortsette når ressursene er lastet opp. Det er fortsatt nødvendig
å kontrollere kartet i GIANTS Editor og FS25 etterpå.

## Hvis Windows blokkerer PowerShell-filen

Hjelperen følger maskinens PowerShell-policy. Noen Windows-PC-er tillater ikke
kjøring av `.ps1`-filer, så dobbeltklikk virker ikke på alle maskiner.

Hvis meldingen gjelder at filen er lastet ned fra Internett, kan du høyreklikke den
nedlastede **hjelpe-ZIP-filen**, velge **Egenskaper**, og bruke **Fjern blokkering**
hvis valget vises. Pakk deretter ut pakken på nytt. Dette fjerner nedlastingsmerket
(Mark-of-the-Web); det endrer ikke PowerShell-policyen.

Hvis meldingen sier at skriptkjøring er deaktivert, for eksempel
**«running scripts is disabled on this system»**, kan policyen være **Restricted**.
Da blokkeres alle `.ps1`-filer, også etter **Fjern blokkering**. Send den nøyaktige
feilmeldingen i chatten, så kan vi finne et passende neste steg. Hjelperen endrer
ikke policyen og forsøker ikke å omgå blokkeringen.

På en administrert PC må gjeldende organisasjonsregler følges. Du kan lese
`Collect-Rennebu-FS22.ps1` før du kjører den.

## Hva den gjør

- Leser bare 295 filbaner fra testloggen pluss to referansefiler (297 relative
  filbaner i `required_paths.json`), og deres filavhengigheter. Ingen hel spillmappe
  kopieres. Referansefilene er `maps/maps_fieldGround.xml` og
  `shaders/fruitGrowthFoliageShader.xml`; de brukes til å undersøke gamle
  bakketilstander og bevare sesongfargene i vegetasjonen.
- Henter blant annet de 13 tre-modellene og `groundFoliage.xml` som manglet.
- Prøver en faktisk `.dds` når en etterspurt `.png` mangler, og motsatt.
  Rapporten viser hvilken fil som faktisk ble funnet. Filene får sine ekte endelser.
- Følger I3D/XML-referanser og shader-includes inne i FS22s `data`-mappe, også
  modellenes eksterne `.shapes`-filer. Filer utenfor `data`, symbolske lenker og
  junctions avvises. XML-entiteter/DTD kjøres ikke.
- Skriver en ZIP med `data/...`-mappestrukturen, en kontrollrapport, og ved behov
  opplastingsdeler. Ingen originalfiler i FS22 endres. Ingen automatisk opplasting,
  nettverkstilkobling, registerendring eller endring av sikkerhetsinnstillinger.
- Stopper ved 10 000 ressurser eller 4 GiB ukomprimerte ressurser. Eksisterende
  eksportmapper overskrives ikke. Det trengs plass til både ZIP og eventuelle deler.

Manglende avhengigheter registreres i `export_report.json`; en ferdig rapport betyr
at eksporten er laget, ikke at alle ressurser nødvendigvis fantes i installasjonen.
`$dataS`, DLC- og mod-referanser utenfor FS22s `data` blir ikke hentet automatisk.
Pakker med FS22-spillressurser er til denne private konverteringen og skal ikke
publiseres i det offentlige GitHub-repositoriet. Selve hjelpepakken inneholder
bare kode og relative filnavn, ingen spillressurser.

## Teknisk kontroll

`audit_report.md` beskriver grunnlaget i testloggen. `test_collector.py` kjører den
faktiske PowerShell-samleren mot en liten testmappe og er bare for utviklerkontroll.
Ingen Python-installasjon er nødvendig for den vanlige Windows-hjelperen.
