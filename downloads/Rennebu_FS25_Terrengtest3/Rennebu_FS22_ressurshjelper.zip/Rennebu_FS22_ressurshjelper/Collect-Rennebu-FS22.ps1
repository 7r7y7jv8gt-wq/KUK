﻿# Collect only the resources listed in required_paths.json and their file dependencies.
# No network calls; the selected FS22 data directory is read-only to this script.
# Compatible with Windows PowerShell 5.1. Command-line options also support fixture tests.
[CmdletBinding()]
param(
    [string]$GameRoot,
    [string]$OutputRoot,
    [string]$RequiredPaths = (Join-Path $PSScriptRoot 'required_paths.json'),
    [ValidateRange(1024,32505856)][int]$PartSizeBytes = 32505856
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$MaxFiles = 10000
$MaxTotalBytes = [long]4294967296
$MaxXmlBytes = [long]33554432
$Utf8 = New-Object System.Text.UTF8Encoding($false)
$Issues = New-Object 'System.Collections.Generic.List[object]'
$Queue = New-Object 'System.Collections.Generic.Queue[object]'
$Requests = New-Object 'System.Collections.Generic.List[object]'
$Assets = New-Object 'System.Collections.Generic.Dictionary[string,object]' ([StringComparer]::OrdinalIgnoreCase)
$SeenRequests = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$TotalBytes = [long]0

function Add-Issue([string]$Kind, [string]$Path, [string]$From, [string]$Detail) {
    $Issues.Add([pscustomobject]@{ kind=$Kind; path=$Path; from=$From; detail=$Detail })
}
function Find-GameRoot {
    $candidates = New-Object 'System.Collections.Generic.List[string]'
    foreach ($base in @(${env:ProgramFiles(x86)}, $env:ProgramFiles, 'C:\SteamLibrary', 'D:\SteamLibrary', 'E:\SteamLibrary')) {
        if ($base) {
            $candidates.Add((Join-Path $base 'Steam\steamapps\common\Farming Simulator 22'))
            $candidates.Add((Join-Path $base 'steamapps\common\Farming Simulator 22'))
            $candidates.Add((Join-Path $base 'Farming Simulator 2022'))
        }
    }
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath (Join-Path $candidate 'data') -PathType Container) { return $candidate }
    }
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Velg mappen der Farming Simulator 22 er installert (eller data-mappen i FS22).'
    $dialog.ShowNewFolderButton = $false
    try {
        if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { throw 'Ingen FS22-mappe valgt.' }
        return $dialog.SelectedPath
    } finally { $dialog.Dispose() }
}
function Assert-NoReparse([string]$FullPath) {
    # Junctions and symbolic links could escape the selected data directory.
    $cursor = $FullPath
    while ($cursor.Length -ge $script:DataRoot.Length) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -LiteralPath $cursor -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Symbolic link/junction is not collected.' }
        }
        if ($cursor.Equals($script:DataRoot, [StringComparison]::OrdinalIgnoreCase)) { break }
        $parent = [IO.Path]::GetDirectoryName($cursor)
        if (!$parent -or $parent -eq $cursor) { break }
        $cursor = $parent
    }
}
function Get-RelativeAsset([string]$Value, [string]$BaseRelative) {
    $valuePath = $Value.Trim().Replace('\','/')
    if ($valuePath.StartsWith('$data/', [StringComparison]::OrdinalIgnoreCase)) {
        $valuePath = $valuePath.Substring(6)
        $BaseRelative = ''
    } elseif ($valuePath.Contains('$')) {
        throw 'Only $data references can be resolved.'
    }
    if (!$valuePath -or $valuePath -match '^[\/]|^[A-Za-z]:|[:*?\x00-\x1f]') { throw 'Absolute, empty or wildcard reference is not allowed.' }
    $base = $script:DataRoot
    if ($BaseRelative) { $base = Join-Path $base ($BaseRelative.Replace('/', [IO.Path]::DirectorySeparatorChar)) }
    $full = [IO.Path]::GetFullPath((Join-Path $base ($valuePath.Replace('/', [IO.Path]::DirectorySeparatorChar))))
    if (!$full.StartsWith($script:DataPrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Reference is outside FS22/data.' }
    Assert-NoReparse $full
    return $full.Substring($script:DataPrefix.Length).Replace('\','/')
}
function Add-Request([string]$Value, [string]$BaseRelative, [string]$From) {
    try {
        $relative = Get-RelativeAsset $Value $BaseRelative
        $key = $relative + "`n" + $From
        if ($SeenRequests.Add($key)) {
            $Queue.Enqueue([pscustomobject]@{ path=$relative; from=$From })
        }
    } catch { Add-Issue 'rejected_reference' $Value $From $_.Exception.Message }
}
function Find-ActualAsset([string]$Relative) {
    $candidates = New-Object 'System.Collections.Generic.List[string]'
    $candidates.Add($Relative)
    $extension = [IO.Path]::GetExtension($Relative).ToLowerInvariant()
    if ($extension -eq '.png') { $candidates.Add([IO.Path]::ChangeExtension($Relative, '.dds')) }
    if ($extension -eq '.dds') { $candidates.Add([IO.Path]::ChangeExtension($Relative, '.png')) }
    foreach ($candidate in $candidates) {
        $full = Join-Path $script:DataRoot ($candidate.Replace('/', [IO.Path]::DirectorySeparatorChar))
        if (Test-Path -LiteralPath $full -PathType Leaf) {
            Assert-NoReparse $full
            return [pscustomobject]@{ relative=$candidate; full=$full }
        }
    }
    return $null
}
function Add-Dependencies([string]$Relative, [string]$FullPath) {
    $extension = [IO.Path]::GetExtension($Relative).ToLowerInvariant()
    $parent = [IO.Path]::GetDirectoryName($Relative).Replace('\','/')
    if ($extension -eq '.i3d') {
        # Some versions omit the externalShapesFile attribute; copy a real companion only.
        $companion = $Relative + '.shapes'
        $fullCompanion = Join-Path $script:DataRoot ($companion.Replace('/', [IO.Path]::DirectorySeparatorChar))
        if (Test-Path -LiteralPath $fullCompanion -PathType Leaf) { Add-Request $companion '' $Relative }
    }
    if ($extension -notin @('.i3d','.xml','.gsl','.glsl','.hlsl','.h')) { return }
    if ((Get-Item -LiteralPath $FullPath).Length -gt $MaxXmlBytes) {
        Add-Issue 'parse_skipped' $Relative $Relative 'Structured text exceeds the 32 MiB parser limit.'
        return
    }
    $content = [IO.File]::ReadAllText($FullPath)
    if ($extension -in @('.i3d','.xml')) {
        $reader = $null
        try {
            $settings = New-Object System.Xml.XmlReaderSettings
            $settings.DtdProcessing = [System.Xml.DtdProcessing]::Prohibit
            $settings.XmlResolver = $null
            $reader = [System.Xml.XmlReader]::Create((New-Object System.IO.StringReader($content)), $settings)
            $xml = New-Object System.Xml.XmlDocument
            $xml.XmlResolver = $null
            $xml.Load($reader)
            foreach ($attribute in $xml.SelectNodes('//@*')) {
                $valuePath = [string]$attribute.Value
                # Paths are literal values, never commands. Restrict to resource suffixes.
                if ($valuePath -match '(?i)\.(?:i3d(?:\.shapes)?|xml|dds|png|jpe?g|tga|bmp|gsl|glsl|hlsl|h|ogg|wav)$') {
                    Add-Request $valuePath $parent $Relative
                }
            }
        } catch { Add-Issue 'parse_failed' $Relative $Relative $_.Exception.Message }
        finally { if ($reader) { $reader.Dispose() } }
    }
    # GIANTS shader includes can occur in XML CDATA as well as shader source files.
    foreach ($match in [regex]::Matches($content, '(?im)^\s*#include\s*["<]([^">\r\n]+)[">]')) {
        Add-Request $match.Groups[1].Value $parent $Relative
    }
}
function Get-Sha256([string]$Path) {
    $sha = [Security.Cryptography.SHA256]::Create()
    $stream = [IO.File]::OpenRead($Path)
    try { return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-','').ToLowerInvariant() }
    finally { $stream.Dispose(); $sha.Dispose() }
}
function Add-ZipText($Archive, [string]$Name, [string]$Text) {
    $entry = $Archive.CreateEntry($Name, [IO.Compression.CompressionLevel]::Optimal)
    $stream = $entry.Open()
    $writer = New-Object IO.StreamWriter($stream, $script:Utf8)
    try { $writer.Write($Text) } finally { $writer.Dispose() }
}

try {
    $config = [IO.File]::ReadAllText((Get-Item -LiteralPath $RequiredPaths).FullName) | ConvertFrom-Json
    if ($config.schema_version -ne 1 -or !$config.requested_paths -or $config.requested_paths.Count -gt $MaxFiles) { throw 'Invalid required_paths.json.' }
    if (!$GameRoot) { $GameRoot = Find-GameRoot }
    $gamePath = [IO.Path]::GetFullPath($GameRoot).TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
    if ([IO.Path]::GetFileName($gamePath) -ieq 'data') { $DataRoot = $gamePath }
    else { $DataRoot = Join-Path $gamePath 'data' }
    if (!(Test-Path -LiteralPath $DataRoot -PathType Container)) { throw 'Finner ikke data-mappen. Velg den installerte FS22-mappen.' }
    $DataRoot = [IO.Path]::GetFullPath($DataRoot)
    $DataPrefix = $DataRoot + [IO.Path]::DirectorySeparatorChar
    Assert-NoReparse $DataRoot
    if (!$OutputRoot) {
        $downloads = Join-Path ([Environment]::GetFolderPath('UserProfile')) 'Downloads'
        $OutputRoot = Join-Path $downloads ('Rennebu_FS22_ressurser_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
    }
    $OutputRoot = [IO.Path]::GetFullPath($OutputRoot)
    if ($OutputRoot.Equals($DataRoot, [StringComparison]::OrdinalIgnoreCase) -or $OutputRoot.StartsWith($DataPrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Eksportmappen kan ikke ligge i FS22/data.' }
    if (Test-Path -LiteralPath $OutputRoot) { throw 'Eksportmappen finnes allerede. Velg en ny mappe; eksisterende filer overskrives ikke.' }
    # Also prevent an output-parent junction from redirecting writes into the source data.
    $outputParent = [IO.Path]::GetDirectoryName($OutputRoot)
    while ($outputParent) {
        if (Test-Path -LiteralPath $outputParent) {
            $outputItem = Get-Item -LiteralPath $outputParent -Force
            if (($outputItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Eksportmappen kan ikke ligge under en symbolsk lenke eller junction.' }
        }
        $nextParent = [IO.Path]::GetDirectoryName($outputParent)
        if (!$nextParent -or $nextParent -eq $outputParent) { break }
        $outputParent = $nextParent
    }
    foreach ($requested in $config.requested_paths) { Add-Request ([string]$requested) '' 'required_paths.json' }
    Write-Host 'Leser bare de manglende Rennebu-ressursene og deres avhengigheter fra FS22...'
    while ($Queue.Count -gt 0) {
        $request = $Queue.Dequeue()
        try { $actual = Find-ActualAsset $request.path }
        catch { Add-Issue 'rejected_reference' $request.path $request.from $_.Exception.Message; continue }
        if (!$actual) { Add-Issue 'missing' $request.path $request.from 'No exact file or PNG/DDS alternative found.'; continue }
        $Requests.Add([pscustomobject]@{ requested=$request.path; actual=$actual.relative; from=$request.from })
        if ($Assets.ContainsKey($actual.relative)) { continue }
        $length = (Get-Item -LiteralPath $actual.full).Length
        $TotalBytes += $length
        if ($Assets.Count -ge $MaxFiles -or $TotalBytes -gt $MaxTotalBytes) { throw 'Dependency limit reached (10,000 files / 4 GiB). No archive was made.' }
        $Assets.Add($actual.relative, [pscustomobject]@{ path=$actual.relative; full=$actual.full; bytes=$length })
        Add-Dependencies $actual.relative $actual.full
    }
    if ($Assets.Count -eq 0) { throw 'Ingen av de etterspurte filene ble funnet. Kontroller at du valgte FS22, ikke FS25.' }
    [IO.Directory]::CreateDirectory($OutputRoot) | Out-Null
    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zipPath = Join-Path $OutputRoot 'Rennebu_FS22_ressurser.zip'
    $zipStream = [IO.File]::Open($zipPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    $archive = New-Object IO.Compression.ZipArchive($zipStream, [IO.Compression.ZipArchiveMode]::Create, $false)
    $fileReports = New-Object 'System.Collections.Generic.List[object]'
    try {
        foreach ($key in ($Assets.Keys | Sort-Object)) {
            $asset = $Assets[$key]
            Write-Progress -Activity 'Lager Rennebu FS22-ressurser' -Status $asset.path -PercentComplete ([int](100 * $fileReports.Count / $Assets.Count))
            $entry = $archive.CreateEntry(('data/' + $asset.path), [IO.Compression.CompressionLevel]::Optimal)
            $source = [IO.File]::Open($asset.full, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
            $destination = $entry.Open()
            try { $source.CopyTo($destination) } finally { $source.Dispose(); $destination.Dispose() }
            $fileReports.Add([pscustomobject]@{ path=('data/' + $asset.path); bytes=$asset.bytes; sha256=(Get-Sha256 $asset.full) })
        }
        $manifest = [ordered]@{
            schema_version=1; purpose='Rennebu missing FS22 stock resources for personal FS25 conversion'
            source_log_sha256=$config.source_log_sha256
            requested_root_count=$config.requested_paths.Count; exported_file_count=$Assets.Count; source_bytes=$TotalBytes
            aliases_and_dependencies=@($Requests.ToArray()); issues=@($Issues.ToArray()); files=@($fileReports.ToArray())
        }
        Add-ZipText $archive 'asset_manifest.json' ($manifest | ConvertTo-Json -Depth 8)
    } finally { $archive.Dispose(); $zipStream.Dispose(); Write-Progress -Activity 'Lager Rennebu FS22-ressurser' -Completed }
    $zipBytes = (Get-Item -LiteralPath $zipPath).Length
    $parts = New-Object 'System.Collections.Generic.List[object]'
    if ($zipBytes -gt $PartSizeBytes) {
        $source = [IO.File]::OpenRead($zipPath)
        $buffer = New-Object byte[] 1048576
        try {
            $partIndex = 1
            while ($source.Position -lt $source.Length) {
                $partName = 'Rennebu_FS22_ressurser.zip.part' + $partIndex.ToString('000')
                $partPath = Join-Path $OutputRoot $partName
                $part = [IO.File]::Open($partPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
                try {
                    $remaining = $PartSizeBytes
                    while ($remaining -gt 0 -and ($read = $source.Read($buffer, 0, [Math]::Min($buffer.Length, $remaining))) -gt 0) {
                        $part.Write($buffer, 0, $read); $remaining -= $read
                    }
                } finally { $part.Dispose() }
                $parts.Add([pscustomobject]@{ filename=$partName; bytes=(Get-Item -LiteralPath $partPath).Length; sha256=(Get-Sha256 $partPath) })
                $partIndex++
            }
        } finally { $source.Dispose() }
    }
    $report = [ordered]@{
        schema_version=1; archive='Rennebu_FS22_ressurser.zip'; archive_bytes=$zipBytes; archive_sha256=(Get-Sha256 $zipPath)
        split_format='Raw consecutive bytes of the ordinary ZIP; concatenate parts in numeric order. Not a multipart ZIP format.'
        part_limit_bytes=$PartSizeBytes; parts=@($parts.ToArray()); export=$manifest
    }
    [IO.File]::WriteAllText((Join-Path $OutputRoot 'export_report.json'), ($report | ConvertTo-Json -Depth 10), $Utf8)
    $instructions = @'
Dette er private FS22-ressurser for Rennebu-konverteringen.
Originalfilene i FS22 er ikke endret. Ingen filer er lastet opp automatisk.

Hvis det finnes .part001, .part002 osv.: Last opp ALLE delene og export_report.json i chatten.
Hvis det ikke finnes delfiler: Last opp Rennebu_FS22_ressurser.zip og export_report.json.
Den store ZIP-filen beholdes lokalt. Delene er maksimalt 31 MiB hver.
De er raa biter av samme ZIP, ikke separate ZIP-arkiver. Ikke pakk ut hver del.
Ikke legg spillressursene i et offentlig GitHub-repositorium.

export_report.json viser nøyaktig hvilke filer som ble kopiert, PNG/DDS-valg,
manglende filer og SHA-256-kontrollsummer. Lokale brukerbaner er ikke inkludert.
'@
    [IO.File]::WriteAllText((Join-Path $OutputRoot 'LES_MEG.txt'), $instructions, $Utf8)
    Write-Host ('FERDIG: ' + $OutputRoot)
    Write-Host ('Eksporterte ' + $Assets.Count + ' filer; ' + $Issues.Count + ' oppforinger i avviksrapporten.')
    if ($parts.Count) { Write-Host ('Last opp alle ' + $parts.Count + ' .part-filer og export_report.json i chatten.') }
    else { Write-Host 'Last opp ZIP-filen og export_report.json i chatten.' }
    if ($env:OS -eq 'Windows_NT') { Start-Process explorer.exe -ArgumentList ('"' + $OutputRoot + '"') }
} catch {
    Write-Host ('FEIL: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Ingen FS22-originalfiler er endret. En eventuell ufullstendig eksportmappe kan slettes.'
    exit 1
}
