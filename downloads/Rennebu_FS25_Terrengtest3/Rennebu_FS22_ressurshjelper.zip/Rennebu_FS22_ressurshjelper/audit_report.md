# Missing FS22 resources: Rennebu Test2 audit

Source: latest user-supplied GIANTS Editor log, SHA-256 `e52c0b61fe714b4ef1e13ebdb0a74727e5c00f0a584eb96f1bcfb7820b7257dc`.
Only missing resource paths under the FS25 installation's `data/` directory are
extracted; those paths refer to stock names retained from FS22. The original log's
absolute Windows paths are not copied into this package.

The log contains **295 distinct requested paths**, comprising **270 PNG**, **11 DDS**,
**13 I3D tree models**, and **1 foliage XML**. Two texture stems occur with both
PNG and DDS endings, leaving **293 distinct stems** (279 texture stems plus
13 models and one XML). Actual exported file count depends on installed aliases
and recursively referenced dependencies; this is not a claim that all 295 paths
exist under their requested extensions in FS22.

## Paths by group

| Resource group | Requested paths |
| --- | ---: |
| `foliage/decoBush` | 4 |
| `foliage/decoFoliage` | 11 |
| `foliage/groundFoliage` | 1 |
| `foliage/meadow` | 70 |
| `foliage/weed` | 40 |
| `maps/mapAlpine` | 2 |
| `maps/mapFR` | 3 |
| `maps/mapUS` | 17 |
| `maps/textures` | 4 |
| `maps/trees` | 136 |
| `placeables/lizard` | 7 |

## PNG/DDS aliases already present in the log

- `maps/trees/birch/birch5LOD_mask.png` / `maps/trees/birch/birch5LOD_mask.dds`
- `maps/trees/birch/birchBranch_mask.png` / `maps/trees/birch/birchBranch_mask.dds`

## Thirteen missing tree model roots

- `maps/trees/birch/birch_stage01.i3d`
- `maps/trees/birch/birch_stage02.i3d`
- `maps/trees/birch/birch_stage03.i3d`
- `maps/trees/birch/birch_stage04.i3d`
- `maps/trees/birch/birch_stage05.i3d`
- `maps/trees/cypress/cypress_stage01.i3d`
- `maps/trees/cypress/cypress_stage02.i3d`
- `maps/trees/cypress/cypress_stage03.i3d`
- `maps/trees/cypress/cypress_stage04.i3d`
- `maps/trees/maple/maple_stage02.i3d`
- `maps/trees/pine/pine_stage01.i3d`
- `maps/trees/pine/pine_stage02.i3d`
- `maps/trees/pine/pine_stage03.i3d`

## Foliage root

- `foliage/groundFoliage/groundFoliage.xml`

## Two explicit diagnostic reference requests

The helper also requests two FS22 stock references needed for the next conversion
step. They are additions to the 295 missing paths, not errors found in that log:

- `maps/maps_fieldGround.xml`: inspect the old field-ground type mapping,
  especially the currently undefined old state 15.
- `shaders/fruitGrowthFoliageShader.xml`: recover the legacy seasonal foliage tint.

Neither path duplicates a log request. `required_paths.json` therefore has
**297 explicit root requests**, before discovered dependencies. All paths remain
relative to FS22's `data` directory.

## Export boundary and known limits

The collector follows actual file references from these roots inside the selected
FS22 `data` directory, including associated `.i3d.shapes`, secure XML attributes,
and shader `#include` directives. It does not recursively copy a directory or
search the entire game for approximate names. PNG/DDS extension fallback is
recorded explicitly. `$dataS`, DLC/mod macros, external paths and reparse points
are reported and left unresolved. A manifest records exact archive paths and
SHA-256 checksums. Stock files are read, and the export folder is written.

This package has not been run against the user's FS22 installation because FS22
has not yet been installed there. Compatibility of recovered FS22 geometry,
foliage and shaders with FS25 still needs Editor/game verification and patching.

## Validation

The actual PowerShell collector passed four local fixture tests under PowerShell
7 on Linux: recursive model/shader dependencies plus cycles, PNG/DDS fallback and
deduplication, external references and junction rejection, XML DTD rejection,
ordinary ZIP content and hashes, raw-part reassembly, unchanged source file hashes,
existing-output protection, no output inside source data, and no empty export.
Windows PowerShell 5.1 syntax is used, but a Windows runtime was not available for
an end-to-end GUI/Steam-detection check. The reviewed paths are in
`required_paths.json`; `audit_log.py` reproduces the 295 log paths and appends
the two explicit diagnostic references.
