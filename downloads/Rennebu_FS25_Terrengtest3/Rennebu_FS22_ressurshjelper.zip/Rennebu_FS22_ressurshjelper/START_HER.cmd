@echo off
setlocal
cd /d "%~dp0"
echo Rennebu: samler bare manglende FS22-ressurser til en lokal ZIP.
echo Ingen filer i FS22 endres. Ingen automatisk opplasting.
echo.
powershell.exe -NoLogo -NoProfile -STA -File "%~dp0Collect-Rennebu-FS22.ps1"
echo.
if errorlevel 1 echo Se LES_MEG.md hvis Windows blokkerte PowerShell-filen.
pause
